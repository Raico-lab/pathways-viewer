"""遺伝子・制御関係・カテゴリの編集ダイアログ。"""
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (QCheckBox, QColorDialog, QComboBox, QCompleter, QDialog, QDialogButtonBox,
                             QFormLayout, QLineEdit,
                             QMessageBox, QPlainTextEdit, QPushButton, QVBoxLayout)

from ..db import Category, Interaction, Protein
from ..db.vocab import CATEGORY_PALETTE, EFFECTS, INTERACTION_TYPES


def _text_edit(text: str, height: int = 70) -> QPlainTextEdit:
    edit = QPlainTextEdit(text)
    edit.setFixedHeight(height)
    return edit


class _FormDialog(QDialog):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(460)
        self.form = QFormLayout()
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self._try_accept)
        buttons.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addLayout(self.form)
        layout.addWidget(buttons)

    def validate(self) -> str | None:
        return None

    def _try_accept(self) -> None:
        error = self.validate()
        if error:
            QMessageBox.warning(self, "入力エラー", error)
            return
        self.accept()


class ProteinDialog(_FormDialog):
    def __init__(self, protein: Protein | None, existing_names: set[str], parent=None):
        super().__init__("遺伝子の編集" if protein else "遺伝子の追加", parent)
        self._existing = existing_names - ({protein.gene_name.upper()} if protein else set())
        p = protein or Protein(gene_name="", standard_name="", complex_category="", protein_properties="",
                               description="", basal_activity=None)
        self.gene = QLineEdit(p.gene_name)
        self.standard = QLineEdit(p.standard_name)
        self.properties = QLineEdit(p.protein_properties)
        self.description = _text_edit(p.description)
        self.form.addRow("遺伝子名 *", self.gene)
        self.form.addRow("Systematic 名", self.standard)
        self.form.addRow("ORF の確度（SGD）", self.properties)
        self.form.addRow("機能説明", self.description)

    def validate(self):
        name = self.gene.text().strip()
        if not name:
            return "遺伝子名を入力してください。"
        if name.upper() in self._existing:
            return f"{name} は既に登録されています。"
        return None

    def values(self) -> dict:
        return {
            "gene_name": self.gene.text().strip(),
            "standard_name": self.standard.text().strip(),
            "protein_properties": self.properties.text().strip(),
            "description": self.description.toPlainText().strip(),
        }


class InteractionDialog(_FormDialog):
    def __init__(self, interaction: Interaction | None, proteins: list[Protein], parent=None):
        super().__init__("制御関係の編集" if interaction else "制御関係の追加", parent)
        self._ids = {p.gene_name: p.id for p in proteins}
        names = sorted(self._ids)
        self.source = self._protein_combo(names)
        self.target = self._protein_combo(names)
        self.type = QComboBox()
        self.type.setEditable(True)
        for key, (label, *_rest) in INTERACTION_TYPES.items():
            self.type.addItem(f"{key}（{label}）", key)
        self.effect = QComboBox()
        self.effect.addItem("自動: 種類から決める", None)
        for key, label in EFFECTS.items():
            self.effect.addItem(label, key)
        self.evidence = _text_edit("", 55)
        if interaction:
            self.source.setCurrentText(interaction.source.gene_name)
            self.target.setCurrentText(interaction.target.gene_name)
            idx = self.type.findData(interaction.interaction_type)
            if idx >= 0:
                self.type.setCurrentIndex(idx)
            else:
                self.type.setCurrentText(interaction.interaction_type)
            self.effect.setCurrentIndex(max(0, self.effect.findData(interaction.effect)))
            self.evidence.setPlainText(interaction.evidence)
        self.form.addRow("上流 *", self.source)
        self.form.addRow("下流 *", self.target)
        self.form.addRow("制御の種類", self.type)
        self.form.addRow("作用の向き", self.effect)
        self.form.addRow("根拠・文献", self.evidence)

    @staticmethod
    def _protein_combo(names: list[str]) -> QComboBox:
        combo = QComboBox()
        combo.setEditable(True)
        combo.addItems(names)
        combo.setCurrentIndex(-1)
        completer = QCompleter(names)
        completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        completer.setFilterMode(Qt.MatchFlag.MatchContains)
        combo.setCompleter(completer)
        return combo

    def _type_key(self) -> str:
        text = self.type.currentText().strip()
        idx = self.type.findText(text)
        return self.type.itemData(idx) if idx >= 0 else text.lower()

    def validate(self):
        for combo, label in ((self.source, "上流"), (self.target, "下流")):
            if combo.currentText().strip() not in self._ids:
                return f"{label}の遺伝子が登録されていません。先に遺伝子を追加してください。"
        if not self._type_key():
            return "制御の種類を入力してください。"
        return None

    def values(self) -> dict:
        return {
            "source_id": self._ids[self.source.currentText().strip()],
            "target_id": self._ids[self.target.currentText().strip()],
            "interaction_type": self._type_key(),
            "effect": self.effect.currentData(),
            "evidence": self.evidence.toPlainText().strip(),
        }


class CategoryDialog(_FormDialog):
    def __init__(self, category: Category | None, existing: set[str], parent=None):
        super().__init__("カテゴリの編集" if category else "カテゴリの追加", parent)
        self._existing = existing - ({category.name} if category else set())
        self.name = QLineEdit(category.name if category else "")
        self.is_complex = QCheckBox("複合体として扱う")
        self.is_complex.setChecked(bool(category and category.is_complex))
        self._color = category.color if category else CATEGORY_PALETTE[len(existing) % len(CATEGORY_PALETTE)]
        self.color_button = QPushButton()
        self.color_button.setFixedWidth(80)
        self.color_button.clicked.connect(self._pick_color)
        self._paint()
        self.form.addRow("名前 *", self.name)
        self.form.addRow("", self.is_complex)
        self.form.addRow("色", self.color_button)

    def _paint(self):
        self.color_button.setStyleSheet(f"background:{self._color}; border:1px solid #888; min-height:20px;")

    def _pick_color(self):
        color = QColorDialog.getColor(QColor(self._color), self, "カテゴリの色")
        if color.isValid():
            self._color = color.name()
            self._paint()

    def validate(self):
        name = self.name.text().strip()
        if not name:
            return "名前を入力してください。"
        if name in self._existing:
            return f"{name} は既にあります。"
        return None

    def values(self) -> dict:
        return {"name": self.name.text().strip(), "is_complex": self.is_complex.isChecked(), "color": self._color}
