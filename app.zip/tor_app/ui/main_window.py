"""メインウィンドウ（3 タブ構成）。"""
import subprocess
import sys
import threading

from PyQt6.QtCore import QObject, QUrl, pyqtSignal
from PyQt6.QtGui import QAction, QDesktopServices
from PyQt6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QMainWindow, QMessageBox, QPushButton, QTabWidget,
                             QVBoxLayout, QWidget)

from .. import datastore, server
from ..db import Database
from ..paths import TITLE, TITLE_HTML, user_data_dir
from .db_tab import DatabaseTab
from . import help_text
from .network_tab import NetworkTab
from .sources_tab import SourcesTab

# メニューの「使い方」: Help ボタンと同じ説明（tor_app/ui/help_text.py）に、データの保存場所を加える
HELP_TEXT = f"<h2>{TITLE_HTML}</h2>" + help_text.ALL + """<h3>データの保存</h3>
<p>同梱のデータを初回起動時にこの PC へコピーして使います。編集はこの PC にだけ保存されます。
「ファイル &gt; 同梱データに戻す」で初期状態に戻せます。それまでのデータはバックアップされます。</p>
<h3>データの更新とサーバー</h3>
<p>データを配信するサーバーが設定されていれば、起動時に新しいデータを確かめ、あれば画面の上に案内を出します。
「更新する」で置き換えます。この PC での変更は上書きされ、それまでのデータはバックアップされます。
「ファイル &gt; 最新データを確認」でいつでも確かめられ、「ヘルプ &gt; データの情報」で今のデータの版と取得元が分かります。
説明の日本語訳はサーバーと共有し、ほかの人が訳したものは通信せずに表示できます。
サーバーにつながらないときも、手元のデータでそのまま使えます。</p>"""


class _Done(QObject):
    """裏のスレッドの結果を画面のスレッドに渡す。"""
    update_checked = pyqtSignal(object, bool)   # (server.UpdateStatus, 手動で確認したか)
    downloaded = pyqtSignal(object)             # バックアップのパス、または失敗した例外
    synced = pyqtSignal(int, int)               # 訳を (取り込んだ数, 送った数)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.db: Database | None = None
        self.setWindowTitle(TITLE)
        self.resize(1500, 900)

        self.db_tab = DatabaseTab()
        self.network_tab = NetworkTab()
        self.tabs = QTabWidget()
        self.tabs.addTab(self.network_tab, "ネットワーク")
        self.tabs.addTab(self.db_tab, "データベース")
        self.sources_tab = SourcesTab()
        self.tabs.addTab(self.sources_tab, "情報源")
        # 画面上部の案内（サーバーに新しいデータがあるときだけ出す）
        self.banner = QFrame()
        self.banner.setStyleSheet("QFrame { background: #fff8e1; border-bottom: 1px solid #ffe082; }")
        bar = QHBoxLayout(self.banner)
        bar.setContentsMargins(10, 4, 10, 4)
        self.banner_label = QLabel()
        self.banner_update = QPushButton("更新する")
        self.banner_later = QPushButton("後で")
        self.banner_update.clicked.connect(self.download_update)
        self.banner_later.clicked.connect(self.banner.hide)
        bar.addWidget(self.banner_label, 1)
        bar.addWidget(self.banner_update)
        bar.addWidget(self.banner_later)
        self.banner.hide()
        self._update_status: server.UpdateStatus | None = None
        self._done = _Done()
        self._done.update_checked.connect(self._on_update_checked)
        self._done.downloaded.connect(self._on_downloaded)
        self._done.synced.connect(lambda got, sent: (got or sent) and self.statusBar().showMessage(
            f"訳をサーバーと共有しました。受け取り {got} 件・送信 {sent} 件", 6000))
        central = QWidget()
        column = QVBoxLayout(central)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        column.addWidget(self.banner)
        column.addWidget(self.tabs, 1)
        self.setCentralWidget(central)

        self.db_label = QLabel()
        self.statusBar().addPermanentWidget(self.db_label)
        self.db_tab.changed.connect(self.network_tab.reload)
        self.db_tab.set_network(self.network_tab)
        self.db_tab.translator = self.network_tab.translator   # 訳の保存を共有する
        self.network_tab.databaseEdited.connect(self.db_tab.reload)
        self.network_tab.statusMessage.connect(lambda m: self.statusBar().showMessage(m, 6000))
        self._build_menu()

    def _build_menu(self):
        file_menu = self.menuBar().addMenu("ファイル")
        for text, slot in (("最新データを確認", lambda: self.check_update(manual=True)),
                           ("同梱データに戻す…", self.restore_bundled),
                           ("データの保存フォルダを開く", self.open_data_folder)):
            action = QAction(text, self)
            action.triggered.connect(slot)
            file_menu.addAction(action)
        file_menu.addSeparator()
        quit_action = QAction("終了", self)
        quit_action.triggered.connect(self.close)
        file_menu.addAction(quit_action)
        help_menu = self.menuBar().addMenu("ヘルプ")
        about = QAction("使い方", self)
        about.triggered.connect(lambda: QMessageBox.information(self, "使い方", HELP_TEXT))
        help_menu.addAction(about)
        info = QAction("データの情報", self)
        info.triggered.connect(self.show_data_info)
        help_menu.addAction(info)

    # ---- DB を開く ----
    def start(self) -> bool:
        """起動時にローカル DB を用意して開く。"""
        try:
            if not datastore.LOCAL_DB.exists():
                datastore.install_bundled()
            elif datastore.bundled_is_newer():
                answer = QMessageBox.question(
                    self, "データの更新",
                    "このアプリには新しいデータが同梱されています。\n"
                    "この PC のデータを同梱データに置き換えますか？\n\n"
                    "現在のデータはバックアップフォルダに保存されます。\n"
                    "「いいえ」を選ぶと現在のデータを使い続けます。後で「ファイル > 同梱データに戻す」で更新できます。")
                if answer == QMessageBox.StandardButton.Yes:
                    backup = datastore.install_bundled()
                    self.statusBar().showMessage(f"同梱データに更新しました。バックアップ: {backup}", 10000)
                else:
                    datastore.keep_local()
        except OSError as e:
            QMessageBox.critical(self, "エラー", f"データを準備できませんでした。\n{e}")
            return False
        if not self.open_database():
            return False
        # サーバーがあれば、裏で新しいデータを確かめ、訳を共有する（画面はサーバーの応答を待たない）
        if server.enabled():
            self.check_update(manual=False)
            threading.Thread(target=lambda: self._done.synced.emit(*server.sync_translations(
                self.network_tab.translator)), daemon=True).start()
        return True

    # ---- サーバー（データの更新の通知） ----
    def check_update(self, manual: bool) -> None:
        threading.Thread(target=lambda: self._done.update_checked.emit(server.check_update(), manual),
                         daemon=True).start()

    def _on_update_checked(self, status, manual: bool) -> None:
        self._update_status = status
        label = f"{status.version}版" if status.version else ""
        if status.state == "new":
            self.banner_label.setText(f"新しいデータ {label} があります{'。' + status.notes if status.notes else ''}")
            self.banner_update.show()
            self.banner.show()
        elif status.state == "app_old":
            self.banner_label.setText(f"新しいデータ {label} を使うには、アプリの更新が必要です")
            self.banner_update.hide()
            self.banner.show()
        elif status.state == "latest":
            self.statusBar().showMessage(f"データ: {label} 最新です", 6000)
        elif status.state == "offline":
            self.statusBar().showMessage("サーバーにつながりません。手元のデータで表示しています", 6000)
        if manual and status.state in ("off", "latest", "offline"):
            QMessageBox.information(self, "最新データを確認", {
                "off": "データを配信するサーバーは、まだ設定されていません。",
                "latest": f"この PC のデータは最新です: {label}",
                "offline": "サーバーにつながりませんでした。手元のデータで表示しています。"}[status.state])

    def download_update(self) -> None:
        status = self._update_status
        if not status or not status.manifest:
            return
        answer = QMessageBox.question(
            self, "データの更新",
            "サーバーの新しいデータに置き換えます。\nこの PC での変更は上書きされます。現在のデータはバックアップされます。")
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.banner_label.setText("新しいデータをダウンロードしています…")
        self.banner_update.setEnabled(False)

        def work():
            try:
                self._done.downloaded.emit(server.fetch_update(status.manifest))
            except Exception as e:  # noqa: BLE001
                self._done.downloaded.emit(e)
        threading.Thread(target=work, daemon=True).start()

    def _on_downloaded(self, result) -> None:
        self.banner_update.setEnabled(True)
        self.banner.hide()
        if not isinstance(result, Exception):
            # 置き換えは画面のスレッドで、DB を閉じてから行う
            if self.db:
                self.db.engine.dispose()
            try:
                result = server.install_update(*result, self._update_status.manifest)
            except OSError as e:
                result = e
        if isinstance(result, Exception):
            QMessageBox.warning(self, "データの更新", f"更新できませんでした。元のデータのままです。\n{result}")
            self.open_database()
            return
        if self.open_database():
            QMessageBox.information(self, "完了", "新しいデータに更新しました。"
                                    + (f"\nバックアップ: {result}" if result else ""))

    def show_data_info(self) -> None:
        info = datastore.installed_info()
        source = {"bundled": "アプリに同梱のデータ", "server": "サーバーから取得したデータ"}.get(info.get("source"), "不明")
        lines = [f"取得元: {source}"]
        if info.get("version"):
            lines.append(f"版: {info['version']}")
        if info.get("at"):
            lines.append(f"取り込んだ日時: {info['at']}")
        lines.append(f"保存場所: {datastore.LOCAL_DB}")
        lines.append("サーバー: " + (server.config().get("base_url") if server.enabled() else "未設定"))
        QMessageBox.information(self, "データの情報", "\n".join(lines))

    def open_database(self) -> bool:
        if self.db:
            self.db.engine.dispose()
        try:
            db = Database(str(datastore.LOCAL_DB))
            db.proteins()  # 接続確認
        except Exception as e:  # noqa: BLE001 - 破損などを利用者に伝える
            QMessageBox.critical(self, "DB を開けません",
                                 f"{e}\n\n「ファイル > 同梱データに戻す」で初期状態に戻せます。")
            return False
        self.db = db
        self.db_tab.set_database(db)
        self.network_tab.set_database(db)
        self.sources_tab.set_database(db)
        self.db_label.setText(f"データ: {datastore.LOCAL_DB}")
        return True

    def restore_bundled(self):
        answer = QMessageBox.question(
            self, "同梱データに戻す",
            "この PC のデータを、アプリに同梱されたデータに置き換えます。\n"
            "現在のデータはバックアップフォルダに保存されます。よろしいですか？")
        if answer != QMessageBox.StandardButton.Yes:
            return
        if self.db:
            self.db.engine.dispose()
        try:
            backup = datastore.install_bundled()
        except OSError as e:
            QMessageBox.critical(self, "エラー", f"置き換えできませんでした。\n{e}")
            return
        if self.open_database():
            QMessageBox.information(self, "完了", "同梱データに戻しました。"
                                    + (f"\nバックアップ: {backup}" if backup else ""))

    def open_data_folder(self):
        folder = str(user_data_dir())
        if sys.platform == "darwin":
            subprocess.run(["open", folder], check=False)
        else:
            QDesktopServices.openUrl(QUrl.fromLocalFile(folder))
