"""② ネットワークタブ：表示枠（GraphPane）を並べて描画する。

表示枠ごとに注目遺伝子・段数・戻る/進む履歴・表示する TFs を持つ。モデル・詳細パネルは共有する。
左側には、操作中の表示枠で注目している遺伝子の TFs（転写制御する転写因子）をチェックボックスで並べる。
"""
import html
import json
import re
import threading
from dataclasses import dataclass, field

from PyQt6.QtCore import QObject, Qt, QTimer, QUrl, pyqtSignal
from PyQt6.QtGui import QColor, QDesktopServices, QFont, QFontMetrics, QKeySequence, QShortcut
from PyQt6.QtWidgets import (QAbstractItemView, QApplication, QSizePolicy, QButtonGroup, QCheckBox, QComboBox, QFrame, QGroupBox, QToolButton, QHBoxLayout, QLabel,
                             QListWidget, QListWidgetItem, QPushButton, QRadioButton, QScrollArea, QSpinBox, QSplitter, QTabWidget, QTextBrowser,
                             QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from .. import complex_groups, conditions, confidence, expression, relation_paths
from ..db import Database
from ..db.vocab import DETAILS, EFFECTS, INTERACTION_TYPES, detail_text, resolve_effect, type_label
from ..graph_data import PathwayModel
from ..paths import resource_path, user_data_dir
from ..translate import Translator, failure_reason
from . import help_text
from .gene_set_window import GeneSetPane, MapWindow
from .saved_views import SavedViewsPanel
from .graph_pane import DEFAULT_DOWN, DEFAULT_UP, GraphPane

LAYOUT_CHOICES = [
    ("階層（縦）", "dagre_tb"),
    ("階層（横）", "dagre_lr"),
    ("同心円", "concentric"),
    ("格子", "grid"),
]

VIEW_FILE = user_data_dir() / "view.json"
MAX_PANES = 4
MAX_LIST = 40            # 詳細パネルに並べる上流・下流の最大数

# 根拠欄の項目の出典（先頭の語で見分ける）: (見出し, 色)
EVIDENCE_SOURCES = [
    ("⚠", ("食い違い", "#e65100")),
    ("文献で確認", ("文献", "#ad1457")),
    ("作用の向き: IDEA", ("IDEA", "#00695c")),
    ("SGD GO 注釈", ("SGD の GO 注釈", "#5d4037")),
    ("作用の向き: GO-CAM", ("GO-CAM", "#5d4037")),
    ("GO-CAM", ("GO-CAM", "#5d4037")),
    ("作用の向き: 破壊株データ", ("破壊株データからの推定", "#6a1b9a")),
    ("破壊株データ", ("破壊株データ", "#6a1b9a")),
    ("BioGRID", ("BioGRID", "#1565c0")),
    ("YEASTRACT", ("YEASTRACT+", "#00838f")),
    ("TF acting", ("YEASTRACT+", "#00838f")),
    ("activator と inhibitor", ("YEASTRACT+", "#00838f")),
    ("公開データ", ("公開データ", "#455a64")),
    ("注記", ("BioGRID の注記", "#1565c0")),
    ("サンプル", ("サンプル", "#9e9e9e")),
]


@dataclass
class DetailState:
    """説明欄の開閉の状態。地図とデータベースの説明欄は同じ関数（NetworkTab.render_html）で中身を作り、状態だけを別に持つ。"""
    show_translation: bool = False                          # 英語の説明の訳を出すか
    open_lists: set[str] = field(default_factory=set)        # 上流・下流の一覧で、畳んだ分を開いているもの（up / down）
    open_conds: set[str] = field(default_factory=set)        # 条件ごとの変化で、測定の一覧を開いている条件
    width: int = 0                                           # 説明欄の幅（px。0 なら地図の説明欄の幅）。条件名の折り返しに使う

    def reset(self) -> None:
        """別の遺伝子・線を開いたとき: 訳と一覧を閉じる（開いた条件は、続けて比べられるように残す）。"""
        self.show_translation = False
        self.open_lists = set()


class WidthWatcher(QObject):
    """説明欄の幅が変わったら、少し待ってから changed を出す（条件名の折り返しを幅に合わせて作り直すため）。"""
    changed = pyqtSignal()

    def __init__(self, widget):
        super().__init__(widget)
        self._width = widget.width()
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(150)
        self._timer.timeout.connect(self.changed)
        widget.installEventFilter(self)

    def eventFilter(self, obj, event):
        if event.type() == event.Type.Resize and obj.width() != self._width:
            self._width = obj.width()
            self._timer.start()
        return False


class _TranslationSignal(QObject):
    """翻訳のスレッドから画面へ結果を渡す（原文, 訳（失敗したら None）, 失敗の理由）。"""
    done = pyqtSignal(str, object, str)


class NetworkTab(QWidget):
    statusMessage = pyqtSignal(str)
    databaseEdited = pyqtSignal()
    translationDone = pyqtSignal()   # 説明の訳が届いた（データベースの説明欄も出し直す）

    def __init__(self, parent=None):
        super().__init__(parent)
        self.db: Database | None = None
        self.model: PathwayModel | None = None
        self.selected: tuple[str, object] | None = None
        self.detail_pane: GraphPane | None = None     # 詳細パネルに表示中の選択元の枠
        # 遺伝子の説明の日本語訳（基本は英語の原文だけ。「日本語訳を表示」を押したときだけ原文の下に訳を出す）
        self.translator = Translator()
        self.detail_state = DetailState()
        self._st = self.detail_state   # 説明欄を作っている間の状態（render_html でデータベースの状態に差し替える）
        self._render_pane = True       # 説明欄に操作中の表示枠の情報（表示されていない数など）を出すか
        self._translating: set[str] = set()
        self._translate_failed: dict[str, str] = {}   # 原文 → 失敗の理由
        self._translation_signal = _TranslationSignal()
        self._translation_signal.done.connect(self._on_translated)

        self.panes: list[GraphPane] = []
        self.gene_windows: list[MapWindow] = []   # 「別ウィンドウで開く」で開いた地図
        self.active_pane: GraphPane | None = None
        self.col_splitters: list[QSplitter] = []   # 表示枠の列（左・右）。列の中は上下に並べる

        self._build_toolbar()
        # 凡例のチェックボックスで隠した項目（全表示枠に共通）
        self.hidden: dict[str, set[str]] = {"roles": set(), "types": set(), "effects": set()}
        self._build_trf_panel()
        self._build_detail_panel()
        self.pane_area = QSplitter(Qt.Orientation.Horizontal)
        self.pane_area.setChildrenCollapsible(False)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(self.left_tabs)
        splitter.addWidget(self.pane_area)
        splitter.addWidget(self.detail_panel)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([290, 910, 300])
        layout = QVBoxLayout(self)
        layout.addWidget(splitter, 1)

        for key, action in ((QKeySequence.StandardKey.Back, lambda p: p.go_back()),
                            (QKeySequence.StandardKey.Forward, lambda p: p.go_forward())):
            shortcut = QShortcut(QKeySequence(key), self)
            shortcut.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
            shortcut.activated.connect(lambda a=action: self.active_pane and a(self.active_pane))

        states, layout_name, color_mode, hidden, edge_color, display = self._load_view()
        self.display_options = dict(self.DEFAULT_DISPLAY)
        self.display_options.update({k: bool(v) for k, v in display.items() if k in self.display_options})
        self._set_hidden_filters(hidden)
        self.layout_combo.blockSignals(True)
        self.layout_combo.setCurrentIndex(max(0, self.layout_combo.findData(layout_name)))
        self.layout_combo.blockSignals(False)
        self.color_combo.blockSignals(True)
        self.color_combo.setCurrentIndex(max(0, self.color_combo.findData(color_mode)))
        self.color_combo.blockSignals(False)
        self.edge_color_combo.blockSignals(True)
        self.edge_color_combo.setCurrentIndex(max(0, self.edge_color_combo.findData(edge_color)))
        self.edge_color_combo.blockSignals(False)
        self._sync_data_cond_enabled()
        for state in states:
            self._create_pane(state)
        self._arrange()
        self.set_active(self.panes[0])

    # ================= 構築 =================
    def _build_toolbar(self):
        # 配置・遺伝子の色・線の色は全表示枠に共通の設定。値はここの選択肢が持ち、画面には各表示枠の検索窓の下に
        # 同じ選択肢を出す（GraphPane.view_bar。どれかを変えると、ここを通して全表示枠の選択肢をそろえる）
        self.layout_combo = QComboBox()
        for label, key in LAYOUT_CHOICES:
            self.layout_combo.addItem(label, key)
        self.layout_combo.setToolTip("遺伝子の配置\n階層（縦）: 制御する側が上になるよう段に並べる\n階層（横）: 制御する側が左になるよう列に並べる\n"
                                     "同心円: つながりの多い遺伝子ほど内側に置く\n格子: 配置の番号の順に格子状に並べる")
        self.layout_combo.currentIndexChanged.connect(lambda: self._save_view())   # 次回も同じ配置の方式で開く
        # 選んだらすぐ全表示枠に反映する
        self.layout_combo.currentIndexChanged.connect(
            lambda: self._all_js(f"app.runLayout({json.dumps(self.layout_name())})"))
        self.color_combo = QComboBox()
        self.color_combo.addItem("役割", "role")
        self.color_combo.addItem("階層", "level")
        tip = ("遺伝子の色\n役割: SGD の機能説明から推定したキナーゼ・転写制御因子などの分類\n"
               "階層: ネットワーク全体で上流の起点から何段目か。青＝上流側 → 赤紫＝下流側")
        if expression.available():
            for key, label in expression.KINDS.items():
                self.color_combo.addItem(label, key)
            tip += ("\n発現・リン酸化・タンパク質量: 右の「条件」で選んだ条件での、対照との log2 比。"
                    "赤＝増える、青＝減る、灰＝データなし")
        self.color_combo.setToolTip(tip)
        self.color_combo.currentIndexChanged.connect(lambda: self._save_view())
        self.color_combo.currentIndexChanged.connect(
            lambda: self._all_js(f"app.setColorMode({json.dumps(self.color_mode())})"))
        # 発現・リン酸化・タンパク質量で色分けするときの条件（データのある条件だけ。data/expression.db）
        self.data_cond_combo = QComboBox()
        labels = conditions.labels()
        for key in expression.condition_keys():
            self.data_cond_combo.addItem(labels.get(key, key), key)
        self.data_cond_combo.setToolTip("発現・リン酸化・タンパク質量で色分けするときの条件\n"
                                        "その種類のデータがない条件では、遺伝子はすべて灰色になります")
        saved = self._load_setting("data_condition", "", set(expression.condition_keys()))
        self.data_cond_combo.setCurrentIndex(max(0, self.data_cond_combo.findData(saved or "rapamycin")))
        self.data_cond_combo.currentIndexChanged.connect(lambda: self._save_view())
        for combo in (self.color_combo, self.data_cond_combo):
            combo.currentIndexChanged.connect(lambda _i: self._push_data_values())
        self._data_cache: tuple[tuple, str] | None = None
        self._sync_data_cond_enabled()
        self.edge_color_combo = QComboBox()
        self.edge_color_combo.addItem("修飾・制御", "type")
        self.edge_color_combo.addItem("作用", "effect")
        self.edge_color_combo.setToolTip("線の色\n修飾・制御: 修飾・制御の種類で色分け。リン酸化＝橙、転写制御＝青など\n"
                                         "作用: 促進＝赤、抑制＝青、作用不明＝灰、結合＝薄い灰")
        self.edge_color_combo.currentIndexChanged.connect(lambda: self._save_view())
        self.edge_color_combo.currentIndexChanged.connect(
            lambda: self._all_js(f"app.setEdgeColorMode({json.dumps(self.edge_color_mode())})"))

        for combo in (self.layout_combo, self.color_combo, self.edge_color_combo):
            combo.currentIndexChanged.connect(lambda _i: self.sync_view_choices())

    def view_choices(self) -> list[tuple[str, QComboBox]]:
        """表示枠の検索窓の下に出す、全表示枠に共通の選択肢: (見出し, 値を持つ選択肢)。"""
        # 見出しは短くする（表示枠を 2 列に並べても枠が広がりすぎないように。説明は選択肢のツールチップ）
        choices = [("配置", self.layout_combo), ("色", self.color_combo)]
        if self.data_cond_combo.count():
            choices.append(("条件", self.data_cond_combo))
        return choices + [("線", self.edge_color_combo)]

    def data_kind(self) -> str | None:
        """発現・リン酸化・タンパク質量で色分けしているなら、その種類（mrna / phospho / protein）。"""
        mode = self.color_mode()
        return mode if mode in expression.KINDS else None

    def data_condition(self) -> str | None:
        return self.data_cond_combo.currentData()

    def _sync_data_cond_enabled(self) -> None:
        self.data_cond_combo.setEnabled(self.data_kind() is not None)

    def data_js(self) -> str:
        """地図の遺伝子に、選んだ条件・種類の値を渡す JavaScript（色分けが発現などでなければ空の表）。
        値は遺伝子名 → [log2 の比, 補足（リン酸化の部位）]。同じ条件・種類・地図の DB なら作り直さない。"""
        kind, cond = self.data_kind(), self.data_condition()
        if not kind or not cond or self.model is None:
            return "app.setDataValues({}, null)"
        key = (kind, cond, id(self.model))
        if self._data_cache is None or self._data_cache[0] != key:
            vals = expression.values(kind, cond)
            by_gene = {p.gene_name: [round(v[0], 3), v[1]] for p in self.model.proteins.values()
                       if (v := vals.get((p.standard_name or "").upper())) is not None}
            label = f"{expression.KINDS[kind]}・{conditions.labels().get(cond, cond)}"
            self._data_cache = (key, f"app.setDataValues({json.dumps(by_gene, ensure_ascii=False)}, "
                                     f"{json.dumps(label, ensure_ascii=False)})")
        return self._data_cache[1]

    def _push_data_values(self) -> None:
        self._sync_data_cond_enabled()
        self.sync_view_choices()
        self._all_js(self.data_js())
        if self.selected and self.selected[0] == "node":
            self._refresh_detail_text()

    def sync_view_choices(self) -> None:
        """全表示枠（別ウィンドウも）の、配置・遺伝子の色・線の色の選択肢を今の値にそろえる。"""
        for pane in self._views() if hasattr(self, "panes") else []:
            pane.sync_view_choices()

    def hidden_filters(self) -> dict[str, list[str]]:
        """凡例のチェックを外した（隠す）項目。"""
        return {kind: sorted(keys) for kind, keys in self.hidden.items()}

    def _set_hidden_filters(self, hidden: dict) -> None:
        self.hidden = {kind: set(hidden.get(kind, [])) for kind in ("roles", "types", "effects")}

    def toggle_filter(self, kind: str, key: str, shown: bool, pane: GraphPane | None = None) -> None:
        """どれかの表示枠の凡例でチェックを切り替えたとき。全表示枠に反映し、操作した枠の戻る・進むの履歴に残す。"""
        if kind not in self.hidden:
            return
        for part in key.split("|"):   # 凡例で 1 行にまとめた項目（機構不明の促進・抑制など）
            (self.hidden[kind].discard if shown else self.hidden[kind].add)(part)
        self._on_filter_changed()
        self._record_filters(pane)

    def reset_filters(self, kind: str | None = None, pane: GraphPane | None = None) -> None:
        """凡例のチェックを表示に戻す（kind を指定すると、その欄だけ。effects / types / roles）。"""
        for k in self.hidden:
            if kind is None or k == kind:
                self.hidden[k] = set()
        self._on_filter_changed()
        self._record_filters(pane)

    def _on_filter_changed(self) -> None:
        for pane in self._views():
            pane.push_filters()
        self._save_view()

    DEFAULT_DISPLAY = {"symbols": False, "more": True, "lod": False}   # 凡例の「表示」欄の最初の状態

    def reset_settings(self, pane: GraphPane) -> None:
        """「設定をクリア」: TFs（押した表示枠）・経路・条件・配置・色・線・凡例を最初の状態に戻す。
        注目・拡張・段数は変えない。戻る（◀）で TFs・凡例・条件は元に戻せる。"""
        pane.activate()
        for combo, value in ((self.layout_combo, LAYOUT_CHOICES[0][1]), (self.color_combo, "role"),
                             (self.edge_color_combo, "type"), (self.data_cond_combo, "rapamycin")):
            index = combo.findData(value)
            if index >= 0 and combo.currentIndex() != index:
                combo.setCurrentIndex(index)   # 変えたものだけ地図に反映される
        self._set_hidden_filters({})
        self.display_options = dict(self.DEFAULT_DISPLAY)
        for view in self._views():
            view.push_label_options()
        self.set_condition_top(False)
        self.set_conditions_off(set(), record=False)
        if pane in self.panes:
            self.set_relation_settings([], "off", 1, None)
        pane.trf = set()
        pane._record_history()
        pane.refresh_view(keep_positions=True)
        self._save_view()
        self.statusMessage.emit("設定を最初の状態に戻しました")

    def filter_state(self) -> dict:
        """戻る・進むで覚える、全表示枠に共通の絞り込み（凡例で隠した項目・条件タブで外した条件・最も上流の経路）。"""
        return {"hidden": self.hidden_filters(), "conditions_off": sorted(getattr(self, "conditions_off", ())),
                "conditions_top": self.cond_top.isChecked() if hasattr(self, "cond_top") else False}

    def apply_filter_state(self, state: dict) -> None:
        """戻る・進むで、凡例・条件タブのチェックを履歴の内容に戻す（履歴には新しく残さない）。"""
        if state.get("hidden") != self.hidden_filters():
            self._set_hidden_filters(state.get("hidden", {}))
            self._on_filter_changed()
        self.cond_top.blockSignals(True)
        self.cond_top.setChecked(bool(state.get("conditions_top", False)))
        self.cond_top.blockSignals(False)
        self.set_conditions_off(set(state.get("conditions_off", [])), record=False)

    def _record_filters(self, pane: GraphPane | None = None) -> None:
        """凡例・条件タブのチェックを変えたとき: 操作した表示枠（なければ操作中の枠）の戻る・進むの履歴に残す。"""
        pane = pane or self.active_pane
        if pane is not None and pane.model:
            pane._record_history()

    def _build_trf_panel(self):
        """左側: オレンジで注目した遺伝子を転写制御する転写因子（TFs）の一覧。チェックするとマップの一番上の段に出す。"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        self.trf_layout = QVBoxLayout()
        layout.addLayout(self.trf_layout)
        layout.addStretch(1)
        layout.addWidget(self.help_button("trf"))
        self.trf_scroll = QScrollArea()
        self.trf_scroll.setWidget(panel)
        self.trf_scroll.setWidgetResizable(True)
        self.trf_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        # 左側はタブで切り替える: TFs（転写因子）と、経路（選んだ遺伝子どうしの経路）
        self.left_tabs = QTabWidget()
        self.left_tabs.setMinimumWidth(290)   # 「経路」の中身（表示経路の選択肢など）が横にはみ出さない幅
        self.left_tabs.addTab(self.trf_scroll, "TFs")
        self.left_tabs.addTab(self._build_relation_panel(), "経路")
        self.left_tabs.addTab(self._build_condition_panel(), "条件")
        self.saved_views = SavedViewsPanel(self)
        saved_scroll = QScrollArea()
        saved_scroll.setWidget(self.saved_views)
        saved_scroll.setWidgetResizable(True)
        saved_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.left_tabs.addTab(saved_scroll, "登録")

    def _build_condition_panel(self) -> QWidget:
        """左の「条件」タブ: 関係が働く条件（data/conditions.csv。YEASTRACT+ の環境条件の群・小群と、細胞周期の時期）を
        チェックボックスで選ぶ。すべてオンなら普段の地図。外した条件があれば、チェックした条件の関係（線）とその両端の遺伝子だけを地図で
        目立たせ、ほかは薄くする。並べるのは DB の関係に付いている条件だけ（群ごとに開閉。最初は閉じている）。"""
        try:
            view = json.loads(VIEW_FILE.read_text(encoding="utf-8"))
            saved, top = view.get("conditions_off", []), bool(view.get("conditions_top", False))
        except (OSError, ValueError, AttributeError):
            saved, top = [], False
        self.conditions_off: set[str] = {k for k in saved if k in self._all_condition_keys()}
        self._cond_boxes: dict[str, QCheckBox] = {}
        self._cond_heads: list[tuple[QCheckBox, list[str]]] = []
        panel = QWidget()
        outer = QVBoxLayout(panel)
        # 最も上流の経路: 条件に合う線のうち、経路の起点になるもの（上流に同じく条件に合う線がない線）だけを目立たせる
        self.cond_top = QCheckBox("最も上流の経路を表示")
        self.cond_top.setChecked(top)
        self.cond_top.toggled.connect(lambda _on: (self._all_js(self.condition_js()), self._save_view(),
                                                   self._record_filters()))
        outer.addWidget(self.cond_top)   # 「すべて選択」「すべて解除」では変わらない
        buttons = QHBoxLayout()
        for text, on in (("すべて選択", True), ("すべて解除", False)):
            b = QPushButton(text)
            b.clicked.connect(lambda _=False, on=on: self.set_conditions_off(set() if on else set(self._all_condition_keys())))
            buttons.addWidget(b)
        outer.addLayout(buttons)
        self.cond_layout = QVBoxLayout()
        outer.addLayout(self.cond_layout)
        outer.addStretch(1)
        outer.addWidget(self.help_button("conditions"))
        scroll = QScrollArea()
        scroll.setWidget(panel)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        return scroll

    def _rebuild_condition_panel(self) -> None:
        """条件タブの中身を、今の DB の関係に付いている条件で作り直す（DB を読み直したとき）。"""
        self._clear_layout(self.cond_layout)
        self._cond_boxes, self._cond_heads = {}, []
        self._cond_labels: dict[str, QLabel] = {}
        self._cond_head_labels: list[tuple[QLabel, list[str]]] = []
        counts: dict[str, int] = {}
        for it in self.model.interactions.values():
            for k in conditions.split(it.conditions) or [conditions.NONE_KEY]:
                counts[k] = counts.get(k, 0) + 1
        groups: dict[str, list] = {}
        for c in conditions.load():
            if counts.get(c.key):
                groups.setdefault(c.group, []).append((c.key, c.label))
        groups["記録なし"] = [(conditions.NONE_KEY, conditions.NONE_LABEL)]
        opened = getattr(self, "_cond_open", set())
        self._cond_open = opened
        for group, items in groups.items():
            row = QHBoxLayout()
            arrow = QToolButton()
            arrow.setArrowType(Qt.ArrowType.DownArrow if group in opened else Qt.ArrowType.RightArrow)
            arrow.setAutoRaise(True)
            arrow.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            head, head_label = self._wrap_check(f"{group}（{len(items)}）" if len(items) > 1 else group, bold=True)
            row.addWidget(arrow)
            row.addWidget(head)
            row.addWidget(head_label, 1)
            self.cond_layout.addLayout(row)
            body = QWidget()
            v = QVBoxLayout(body)
            v.setContentsMargins(40, 0, 0, 4)
            v.setSpacing(1)
            for key, label in items:
                cb, text = self._wrap_check(label)
                cb.setChecked(key not in self.conditions_off)
                cb.toggled.connect(lambda on, k=key: self._on_condition_toggled([k], on))
                self._cond_boxes[key] = cb
                self._cond_labels[key] = text
                line = QHBoxLayout()
                line.addWidget(cb)
                line.addWidget(text, 1)
                v.addLayout(line)
            body.setVisible(group in opened)
            self.cond_layout.addWidget(body)

            def toggle(_=False, b=body, a=arrow, g=group):
                show = not b.isVisible()
                b.setVisible(show)
                a.setArrowType(Qt.ArrowType.DownArrow if show else Qt.ArrowType.RightArrow)
                (opened.add if show else opened.discard)(g)

            arrow.clicked.connect(toggle)
            members = [k for k, _ in items]
            head.clicked.connect(lambda on, ks=members: self._on_condition_toggled(ks, on))
            self._cond_heads.append((head, members))
            self._cond_head_labels.append((head_label, members))
        self._sync_condition_heads()
        self._update_condition_presence()

    def _on_condition_toggled(self, keys: list[str], on: bool) -> None:
        for k in keys:
            (self.conditions_off.discard if on else self.conditions_off.add)(k)
            cb = self._cond_boxes.get(k)
            if cb is not None and cb.isChecked() != on:
                cb.blockSignals(True)
                cb.setChecked(on)
                cb.blockSignals(False)
        self._sync_condition_heads()
        self._all_js(self.condition_js())
        self._save_view()
        self._record_filters()

    def _update_condition_presence(self) -> None:
        """条件タブ: 操作中の表示枠の地図に線がある条件はふだんの色、ない条件は灰色にする（凡例と同じ。操作はできる）。"""
        pane = self.active_pane
        if not self.model or pane is None or not getattr(self, "_cond_boxes", None):
            return
        present = set()
        for it in self.model.interactions.values():
            if self.model._edge_shown(it, pane.sub, False):
                present.update(conditions.split(it.conditions) or [conditions.NONE_KEY])
        gray = "color: #9e9e9e;"
        for k, label in self._cond_labels.items():
            label.setStyleSheet("" if k in present else gray)
        for label, members in self._cond_head_labels:
            label.setStyleSheet("font-weight: bold;" + ("" if present & set(members) else gray))

    @staticmethod
    def _wrap_check(text: str, bold: bool = False) -> tuple[QCheckBox, QLabel]:
        """長い名前でも横にはみ出さないよう、チェックボックスと折り返す文字に分ける（文字を押してもチェックが切り替わる）。"""
        cb = QCheckBox()
        label = QLabel(text)
        label.setWordWrap(True)
        label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        if bold:
            label.setStyleSheet("font-weight: bold;")
        label.mousePressEvent = lambda _e, c=cb: c.click()
        return cb, label

    def condition_js(self) -> str:
        """地図に条件タブの状態を渡す JavaScript（外した条件と、「最も上流の経路を表示」）。"""
        return f"app.setConditionFilter({json.dumps(sorted(self.conditions_off))}, {json.dumps(self.cond_top.isChecked())})"

    def set_condition_top(self, on: bool) -> None:
        """「最も上流の経路を表示」を決める（登録の呼び出し。戻る・進むの履歴には残さない）。"""
        self.cond_top.blockSignals(True)
        self.cond_top.setChecked(bool(on))
        self.cond_top.blockSignals(False)
        self._all_js(self.condition_js())
        self._save_view()

    def _all_condition_keys(self) -> list[str]:
        return [c.key for c in conditions.load()] + [conditions.NONE_KEY]

    def set_conditions_off(self, off: set[str], record: bool = True) -> None:
        """外す条件をまとめて決める（「すべて選択」「すべて解除」、登録の呼び出し、戻る・進む）。"""
        self.conditions_off = {k for k in off if k in self._all_condition_keys()}
        for k, cb in self._cond_boxes.items():
            cb.blockSignals(True)
            cb.setChecked(k not in self.conditions_off)
            cb.blockSignals(False)
        self._sync_condition_heads()
        self._all_js(self.condition_js())
        self._save_view()
        if record:
            self._record_filters()

    def _sync_condition_heads(self) -> None:
        """群の見出しのチェックは、群の条件がすべてオンのときだけ付ける。"""
        for head, members in self._cond_heads:
            head.blockSignals(True)
            head.setChecked(all(k not in self.conditions_off for k in members))
            head.blockSignals(False)

    def _build_relation_panel(self) -> QWidget:
        """左の「経路」タブ: 注目・拡張している遺伝子のうちチェックしたものが、どの経路でどう関わるかを一覧にする。
        一覧の経路を選ぶと地図で強調する（tor_app/relation_paths.py）。"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        self.rel_genes_box = QGroupBox("対象の遺伝子")
        genes_layout = QVBoxLayout(self.rel_genes_box)
        self.rel_list = QListWidget()
        # 高さは行数に合わせて固定する（空いた高さに広がらない。表示経路を切り替えて下の一覧が出ても縮まない）
        self.rel_list.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.rel_list.itemChanged.connect(self._on_relation_item_changed)
        check_all = QPushButton("すべて選択")
        check_all.setToolTip("一覧の遺伝子をすべてチェックします")
        check_all.clicked.connect(self._check_all_relation_genes)
        clear = QPushButton("すべて解除")
        clear.clicked.connect(self._clear_relation_checks)
        buttons = QHBoxLayout()
        buttons.addWidget(check_all)
        buttons.addWidget(clear)
        for w in (self.rel_list,):
            genes_layout.addWidget(w)
        genes_layout.addLayout(buttons)
        self._rel_checked: list[int] = []   # 一覧でチェックした遺伝子（チェックした順）

        settings = QHBoxLayout()
        settings.addWidget(QLabel("基準の遺伝子:"))
        self.rel_anchor = QComboBox()
        self.rel_anchor.setToolTip("チェックした遺伝子から選びます。選ぶと、基準の遺伝子が端にある経路だけを一覧にします。\n"
                                   "「基準の遺伝子へ・から作用している経路」では必ず選びます")
        settings.addWidget(self.rel_anchor, 1)
        steps_row = QHBoxLayout()
        steps_row.addWidget(QLabel("経路の段数:"))
        self.rel_steps = QSpinBox()
        self.rel_steps.setRange(1, 3)
        self.rel_steps.setValue(1)
        self.rel_steps.setToolTip("段数がちょうどこの数の経路だけを一覧にします。1 なら直接の関係です。複合体は 1 つとして数えます")
        steps_row.addWidget(self.rel_steps)
        steps_row.addWidget(QLabel("段"))
        steps_row.addStretch(1)

        modes_box = self.rel_modes_box = QGroupBox("表示経路")
        self.rel_modes_layout = QVBoxLayout(modes_box)
        self.rel_mode_group = QButtonGroup(self)
        self._rel_mode_buttons: dict[str, QRadioButton] = {}
        for key, (label, desc, _) in GraphPane.RELATION_MODES.items():
            rb = QRadioButton(label)
            rb.setToolTip(desc)
            rb.setProperty("mode", key)
            rb.setChecked(key == "off")
            self.rel_mode_group.addButton(rb)
            self.rel_modes_layout.addWidget(rb)
            self._rel_mode_buttons[key] = rb
        # 経路の一覧（選んだ表示経路の下に出す）: 同じ上流ごとにまとめ、開くと経路が並ぶ
        self.rel_paths_box = QWidget()
        paths_layout = QVBoxLayout(self.rel_paths_box)
        paths_layout.setContentsMargins(4, 2, 0, 6)
        self.rel_result = QLabel()
        self.rel_result.setWordWrap(True)
        self.rel_result.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.rel_path_filter = QLabel()
        self.rel_path_filter.setWordWrap(True)
        self.rel_path_filter.setStyleSheet("color:#00695c;")
        self.rel_tree = QTreeWidget()
        self.rel_tree.setHeaderHidden(True)
        self.rel_tree.setMinimumHeight(260)
        self.rel_tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.rel_tree.setToolTip("経路を選ぶと地図で強調します。上流や「上流 … 行き先」の組を選ぶと、その中の経路をすべて強調します。\n"
                                 "記号: → 促進、⊣ 抑制、◇ 作用不明。← ⊢ は右から左への矢印。P・Tx などは関係の種類")
        self.rel_tree.itemSelectionChanged.connect(self._on_relation_path_selected)
        self.rel_tree.itemExpanded.connect(self._fill_group)
        for w in (self.rel_path_filter, self.rel_tree):
            paths_layout.addWidget(w)
        self.rel_paths_box.hide()
        self._rel_filter_unit: int | None = None   # 地図でクリックして一覧を絞っている単位

        self.rel_window_button = QPushButton("強調中の遺伝子を新しい枠で開く")
        self.rel_window_button.setToolTip("いま経路タブで強調している遺伝子だけを新しい表示枠に描きます。一覧で経路を選んでいなければ、チェックした遺伝子を描きます。\n"
                                          "その枠の「再配置」は、開いたときの遺伝子の組に戻して配置し直します")
        self.rel_window_button.setEnabled(False)
        self.rel_window_button.clicked.connect(lambda: self.open_relation_pane())
        layout.addWidget(self.rel_genes_box)
        layout.addLayout(settings)
        layout.addLayout(steps_row)
        # 共通の遺伝子などの結果は、表示経路の枠のすぐ下に出す
        for w in (modes_box, self.rel_result, self.rel_window_button):
            layout.addWidget(w)
        layout.addStretch(1)
        layout.addWidget(self.help_button("relation"))
        # 設定を変えたらすぐ反映する（続けて変えたときは最後の設定だけ計算する）
        self._rel_timer = QTimer(self)
        self._rel_timer.setSingleShot(True)
        self._rel_timer.setInterval(200)
        self._rel_timer.timeout.connect(self.apply_relation)
        self.rel_mode_group.buttonToggled.connect(lambda _b, on: on and self._on_relation_setting_changed())
        self.rel_anchor.currentIndexChanged.connect(lambda _i: self._rel_timer.start())
        self.rel_steps.valueChanged.connect(lambda _v: self._rel_timer.start())
        scroll = QScrollArea()
        scroll.setWidget(panel)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._update_relation_genes()
        return scroll

    def _relation_mode(self) -> str:
        button = self.rel_mode_group.checkedButton()
        return button.property("mode") if button else "off"

    def _update_relation_controls(self) -> None:
        mode = self._relation_mode()   # 基準の遺伝子・段数は、表示経路によらずいつでも選べる
        # 経路の一覧を、選んだ表示経路のすぐ下に移す
        self.rel_modes_layout.removeWidget(self.rel_paths_box)
        if mode == "off":
            self.rel_paths_box.hide()
            return
        index = self.rel_modes_layout.indexOf(self._rel_mode_buttons[mode])
        self.rel_modes_layout.insertWidget(index + 1, self.rel_paths_box)
        self.rel_paths_box.show()

    def _on_relation_setting_changed(self) -> None:
        self._update_relation_controls()
        self._rel_timer.start()

    def _relation_targets(self, pane: GraphPane | None) -> list[int]:
        """「経路」の対象にできる遺伝子: 操作中の表示枠で注目（橙）・拡張（紫）している遺伝子。"""
        if pane is None or not self.model:
            return []
        ids = list(dict.fromkeys(pane.focus_ids() + [g for g in pane.grown_order if g in pane.grown]))
        return [p for p in ids if p in self.model.proteins]

    def _update_relation_genes(self) -> None:
        """「経路」タブの一覧を、操作中の表示枠の注目・拡張している遺伝子に合わせる（チェックはそこにあるものだけ残す）。"""
        nodes = self._relation_targets(self.active_pane)
        allowed = set(nodes)
        checked = [p for p in self._rel_checked if p in allowed]
        changed = checked != self._rel_checked
        self._rel_checked = checked
        self.rel_list.blockSignals(True)
        self.rel_list.clear()
        for n in nodes:
            pane = self.active_pane
            # 注目・拡張の区別は文字の色で（地図の印と同じ: 注目＝橙、拡張＝紫）
            item = QListWidgetItem(self.model.names[n])
            item.setForeground(QColor("#e65100" if n in pane.focus_ids() else "#6a1b9a"))
            item.setData(Qt.ItemDataRole.UserRole, n)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Checked if n in checked else Qt.CheckState.Unchecked)
            self.rel_list.addItem(item)
        if not nodes:
            item = QListWidgetItem("地図で遺伝子に注目・拡張すると、ここに並びます")
            item.setFlags(Qt.ItemFlag.NoItemFlags)
            self.rel_list.addItem(item)
        self.rel_list.blockSignals(False)
        rows = max(3, min(10, self.rel_list.count()))   # 3〜10 行分（それより多ければスクロール）
        self.rel_list.setFixedHeight(self.rel_list.sizeHintForRow(0) * rows + 2 * self.rel_list.frameWidth() + 4)
        self._update_relation_checked_label()
        self._update_relation_controls()
        if changed:
            self._rel_timer.start()   # チェックしていた遺伝子が注目・拡張から外れたら、経路を求め直す

    def _update_relation_checked_label(self) -> None:
        # 基準の遺伝子は、チェックした遺伝子から選ぶ（なしも選べる）
        anchor = self.rel_anchor.currentData()
        self.rel_anchor.blockSignals(True)
        self.rel_anchor.clear()
        self.rel_anchor.addItem("なし", None)
        for p in self._rel_checked:
            self.rel_anchor.addItem(self.model.names[p], p)
        if anchor is not None and self.rel_anchor.findData(anchor) >= 0:
            self.rel_anchor.setCurrentIndex(self.rel_anchor.findData(anchor))
        self.rel_anchor.blockSignals(False)

    def _on_relation_item_changed(self, item: QListWidgetItem) -> None:
        pid = item.data(Qt.ItemDataRole.UserRole)
        self._rel_checked = [p for p in self._rel_checked if p != pid]
        if item.checkState() == Qt.CheckState.Checked:
            self._rel_checked.append(pid)
        self._update_relation_checked_label()
        self._rel_timer.start()

    def _check_all_relation_genes(self) -> None:
        """一覧の遺伝子をすべてチェックする（チェックした順は一覧の順）。"""
        for i in range(self.rel_list.count()):
            item = self.rel_list.item(i)
            pid = item.data(Qt.ItemDataRole.UserRole)
            if pid is not None and not item.isHidden() and pid not in self._rel_checked:
                self._rel_checked.append(pid)
        self._update_relation_genes()
        self._rel_timer.start()

    def _clear_relation_checks(self) -> None:
        self._rel_checked = []
        self._update_relation_genes()
        self._rel_timer.start()

    def _on_picked_changed(self, pane: GraphPane, pids: list[int]) -> None:
        self._save_view()   # 緑の選択も次回起動時に戻す（経路のチェックとは独立）

    def apply_relation(self) -> None:
        """「経路」タブの今の設定を、操作中の表示枠に反映し、経路の一覧を作り直す（OFF なら普段の地図に戻す）。"""
        pane = self.active_pane
        if pane is None or not self.model:
            return
        self.rel_result.setText(pane.show_relation(list(self._rel_checked), self._relation_mode(),
                                                   self.rel_steps.value(), self.rel_anchor.currentData()))
        self.rel_window_button.setEnabled(pane.relation is not None)
        self.rel_result.setVisible(bool(self.rel_result.text()))
        count = pane.relation_count()
        self.rel_modes_box.setTitle("表示経路" + (f"　経路 {count} 本" if count is not None else ""))
        self._fill_relation_tree(pane)

    def _edge_marks(self) -> dict[tuple[int, int], set[tuple[str, str]]]:
        """遺伝子の組 → {(線上の記号, 作用)}（経路の一覧の表示用）。"""
        if getattr(self, "_edge_marks_model", None) is not self.model:
            marks: dict[tuple[int, int], set[tuple[str, str]]] = {}
            for it in self.model.interactions.values():
                symbol = INTERACTION_TYPES.get(it.interaction_type, ("", "", "", ""))[3]
                marks.setdefault((it.source_id, it.target_id), set()).add(
                    (symbol, resolve_effect(it.interaction_type, it.effect)))
            self._edge_marks_model, self._edge_marks_cache = self.model, marks
        return self._edge_marks_cache

    # 経路の一覧は 3 段にまとめる: 上流（経路の左端 X）→ 上流と行き先の組（X … A）→ 経路（X → Y → A など）。
    # 経路は数万本になりうるので、組の中の経路の行は、組を開いたときに作る
    ALL_ROWS = Qt.ItemDataRole.UserRole            # 上流・組: その中の経路すべて
    SHOWN_ROWS = Qt.ItemDataRole.UserRole + 1      # 上流・組・経路: いま表示する経路（絞り込み中はその遺伝子を通るものだけ）
    FILLED = Qt.ItemDataRole.UserRole + 2          # 組: 経路の行を作ったか
    CAPPED = Qt.ItemDataRole.UserRole + 3          # 上流・組: 数えるのをやめた（ENUM_CAP に達した）組があるか
    PAIR = Qt.ItemDataRole.UserRole + 4            # 組: (左端, 右端)

    def _fill_relation_tree(self, pane: GraphPane) -> None:
        self._rel_filter_unit = None
        self.rel_path_filter.setText("")
        self.rel_tree.blockSignals(True)
        self.rel_tree.clear()
        r = pane.relation
        if r and "result" in r:
            graph = r["graph"]
            by_left: dict[int, list] = {}   # 上流 → その上流からの組（並びは relation_paths.find の順のまま）
            for group in r["result"].groups:
                by_left.setdefault(group.left, []).append(group)
            for left, groups in by_left.items():
                top = QTreeWidgetItem()
                top.setData(0, self.ALL_ROWS, [row for g in groups for row in g.paths])
                top.setData(0, self.CAPPED, any(g.total >= relation_paths.ENUM_CAP for g in groups))
                top.setData(0, self.PAIR, (left, None))
                for g in groups:
                    pair = QTreeWidgetItem()
                    pair.setData(0, self.ALL_ROWS, g.paths)
                    pair.setData(0, self.CAPPED, g.total >= relation_paths.ENUM_CAP)
                    pair.setData(0, self.PAIR, (g.left, g.right))
                    self._set_pair_rows(pair, graph, g.paths)
                    top.addChild(pair)
                self._update_top(top, graph)
                self.rel_tree.addTopLevelItem(top)
            if self.rel_tree.topLevelItemCount() <= 3:
                for i in range(self.rel_tree.topLevelItemCount()):
                    self.rel_tree.topLevelItem(i).setExpanded(True)
        self.rel_tree.blockSignals(False)

    @staticmethod
    def _count_text(shown: int, total: int, capped: bool) -> str:
        count = f"{total} 本以上" if capped else f"{total} 本"
        return f"{shown} 本 / {count}" if shown != total else count

    def _set_pair_rows(self, pair: QTreeWidgetItem, graph, rows: list) -> None:
        """組（上流 … 行き先）に表示する経路を決める（経路の行は開いたときに作る）。"""
        left, right = pair.data(0, self.PAIR)
        count = self._count_text(len(rows), len(pair.data(0, self.ALL_ROWS)), pair.data(0, self.CAPPED))
        pair.setText(0, f"{graph.label(left)} … {graph.label(right)}（{count}）")
        pair.setData(0, self.SHOWN_ROWS, rows)
        pair.setData(0, self.FILLED, False)
        expanded = pair.isExpanded()
        pair.takeChildren()
        if rows:
            pair.addChild(QTreeWidgetItem(["…"]))   # 開けるようにする仮の行
        pair.setHidden(not rows)
        if expanded and rows:
            self._fill_group(pair)

    def _update_top(self, top: QTreeWidgetItem, graph) -> None:
        """上流のまとめの表示を、中の組（隠れていないもの）に合わせる。"""
        pairs = [top.child(k) for k in range(top.childCount()) if not top.child(k).isHidden()]
        rows = [row for pair in pairs for row in pair.data(0, self.SHOWN_ROWS) or []]
        count = self._count_text(len(rows), len(top.data(0, self.ALL_ROWS)), top.data(0, self.CAPPED))
        left = top.data(0, self.PAIR)[0]
        top.setText(0, f"{graph.label(left)} から（{count}）")
        top.setData(0, self.SHOWN_ROWS, rows)
        top.setHidden(not rows)

    def _fill_group(self, item: QTreeWidgetItem) -> None:
        """組を開いたとき、中の経路の行を作る。"""
        if item.parent() is None or item.data(0, self.PAIR) is None or item.data(0, self.FILLED):
            return
        pane = self.active_pane
        if pane is None or not pane.relation or "graph" not in pane.relation:
            return
        graph, marks, names = pane.relation["graph"], self._edge_marks(), self.model.names
        item.takeChildren()
        children = []
        for row in item.data(0, self.SHOWN_ROWS) or []:
            text = relation_paths.row_text(graph, row, marks)
            child = QTreeWidgetItem([text])
            child.setData(0, self.SHOWN_ROWS, [row])
            edges = sorted(GraphPane.row_edges(graph, row), key=lambda e: (names[e[0]], names[e[1]]))
            child.setToolTip(0, text + "\n関係: " + "、".join(f"{names[x]} → {names[y]}" for x, y in edges))
            children.append(child)
        item.addChildren(children)
        item.setData(0, self.FILLED, True)

    def _on_relation_path_selected(self) -> None:
        pane = self.active_pane
        if pane is None:
            return
        rows, seen = [], set()
        for item in self.rel_tree.selectedItems():
            for row in item.data(0, self.SHOWN_ROWS) or []:
                if id(row) not in seen:
                    seen.add(id(row))
                    rows.append(row)
        if rows:
            pane.highlight_rows(rows)
        else:
            self._relation_unit_rows(pane)   # 選択を外したら、絞り込み中の経路（なければ全体）の表示に戻す

    def _relation_unit_rows(self, pane: GraphPane) -> None:
        """一覧で何も選んでいないとき: 線は描かない（絞り込み中でも、一覧で選ぶまで描かない）。"""
        pane.highlight_rows([])

    def _refilter_tree(self, graph, unit: int | None) -> int:
        """一覧を unit を通る経路だけに絞る（None なら絞り込みを外す）。表示する経路の本数を返す。"""
        shown = 0
        for i in range(self.rel_tree.topLevelItemCount()):
            top = self.rel_tree.topLevelItem(i)
            for k in range(top.childCount()):
                pair = top.child(k)
                rows = pair.data(0, self.ALL_ROWS)
                self._set_pair_rows(pair, graph, rows if unit is None else [row for row in rows if unit in row.nodes])
            self._update_top(top, graph)
            shown += len(top.data(0, self.SHOWN_ROWS))
        return shown

    def _on_relation_gene(self, pane: GraphPane, pid: int) -> None:
        """地図の遺伝子をクリックした: 一覧を、その遺伝子（を含む単位）を通る経路だけに絞って強調する。"""
        if pane is not self.active_pane or not pane.relation or "graph" not in pane.relation:
            return
        graph = pane.relation["graph"]
        unit = graph.unit(pid)
        self._rel_filter_unit = unit
        self.rel_tree.blockSignals(True)
        self.rel_tree.clearSelection()
        shown = self._refilter_tree(graph, unit)
        tops = [self.rel_tree.topLevelItem(i) for i in range(self.rel_tree.topLevelItemCount())]
        if sum(not t.isHidden() for t in tops) <= 3:
            for top in tops:
                if not top.isHidden():
                    top.setExpanded(True)
        self.rel_tree.blockSignals(False)
        name = graph.label(unit)
        self.rel_path_filter.setText(f"{name} を通る経路（{shown} 本）" if shown else f"{name} を通る経路はありません")
        self._relation_unit_rows(pane)

    def _on_relation_background(self, pane: GraphPane) -> None:
        """背景をクリックした: 一覧の絞り込みと選択を外す（地図の強調は地図の側で外れる）。"""
        if pane is not self.active_pane or not pane.relation or "graph" not in pane.relation:
            return
        filtered = self._rel_filter_unit is not None
        self._rel_filter_unit = None
        self.rel_path_filter.setText("")
        self.rel_tree.blockSignals(True)
        self.rel_tree.clearSelection()
        if filtered:
            self._refilter_tree(pane.relation["graph"], None)
        self.rel_tree.blockSignals(False)

    def set_relation_settings(self, genes: list[int], mode: str, steps: int, anchor: int | None) -> None:
        """「経路」タブの設定をまとめて変えて、すぐに反映する（左の「登録」タブから呼び出したとき）。
        チェックは操作中の表示枠で注目・拡張している遺伝子だけ。"""
        widgets = [self.rel_mode_group, self.rel_steps]
        for w in widgets:
            w.blockSignals(True)
        for b in self.rel_mode_group.buttons():
            b.setChecked(b.property("mode") == mode)
        self.rel_steps.setValue(min(3, max(1, steps)))
        for w in widgets:
            w.blockSignals(False)
        self._rel_checked = list(genes)
        self._update_relation_genes()   # 注目・拡張していない遺伝子のチェックは外れる
        index = self.rel_anchor.findData(anchor) if anchor is not None else 0
        self.rel_anchor.blockSignals(True)
        self.rel_anchor.setCurrentIndex(max(0, index))
        self.rel_anchor.blockSignals(False)
        self._rel_timer.stop()
        self.apply_relation()

    def open_relation_pane(self) -> None:
        """いま経路タブで強調している遺伝子（一覧で選んで描いている経路。なければチェックした遺伝子）だけを、
        新しい表示枠で開く（開いたときの状態を保つ）。"""
        pane = self.active_pane
        if pane is None or pane.relation is None or not self.model:
            return
        if len(self.panes) >= MAX_PANES:
            self.statusMessage.emit(f"表示枠は最大 {MAX_PANES} つまでです")
            return
        r = pane.relation
        names = self.model.names
        nodes = set(r["nodes"]) | set(r.get("sel_nodes", set()))
        edges = set(r.get("sel_edges", set()))
        label = GraphPane.RELATION_MODES.get(r["mode"], ("",))[0]
        state = {"focus": [], "gene_set": sorted(names[n] for n in nodes),
                 "gene_set_edges": sorted([names[a], names[b]] for a, b in edges),
                 "gene_set_ends": [names[n] for n in r["pids"]],
                 "gene_set_title": f"経路: {label}・{r['steps']} 段"}
        new = self._create_pane(state)
        self._arrange()
        self.set_active(new)
        new.on_model_reloaded(use_default=False)
        self._save_view()
        self.statusMessage.emit(f"強調中の遺伝子 {len(nodes)} 個を新しい枠で開きました")

    def _make_pane(self, state: dict | None) -> GraphPane:
        """表示枠を作る（state に "gene_set" があれば、遺伝子の組を固定した枠）。"""
        if state and "gene_set" in state:
            return GeneSetPane(self, state)
        return GraphPane(self, state)

    def detach_pane(self, pane: GraphPane) -> None:
        """表示枠の「別ウィンドウで開く」: 枠が 1 つなら今の内容を写した別ウィンドウを開き、
        2 つ以上なら、その枠を別ウィンドウに移す（メインの地図からは消す）。"""
        if not self.model:
            return
        state = pane.state()
        moved = len(self.panes) > 1 and pane in self.panes
        wpane = self._make_pane(state)
        self._wire_window_pane(wpane)
        title = "、".join(state.get("focus", [])) or state.get("gene_set_title") or "地図"
        window = MapWindow(wpane, f"地図: {title}")
        self.gene_windows.append(window)
        window.destroyed.connect(lambda _=None, w=window: self.gene_windows.remove(w) if w in self.gene_windows else None)
        wpane.on_model_reloaded(use_default=False)
        window.show()
        if moved:
            self.close_pane(pane)
        self.statusMessage.emit("表示枠を別ウィンドウに移しました" if moved else "今の表示を別ウィンドウで開きました")

    def _wire_window_pane(self, wpane: GraphPane) -> None:
        """別ウィンドウの表示枠: 詳細欄・凡例・状態表示はメインの画面とつなぐ（左のタブ・枠の管理とはつながない）。"""
        wpane.set_completer(self._gene_names())
        wpane.nodeClicked.connect(lambda p, pid: self.show_node(pid, p))
        wpane.edgeClicked.connect(lambda p, iid: self.show_edge(iid, p))
        wpane.complexClicked.connect(lambda p, name: self.show_complex(name, p))
        wpane.statusMessage.connect(self.statusMessage)
        wpane.helpRequested.connect(lambda _p: self.show_help("legend"))
        wpane.filterToggled.connect(lambda kind, key, shown, p=wpane: self.toggle_filter(kind, key, shown, p))
        wpane.filterReset.connect(lambda kind, p=wpane: self.reset_filters(kind, p))
        wpane.displayOptionChanged.connect(self.set_display_option)

    def _views(self) -> list[GraphPane]:
        """設定（配置・色・凡例・閾値の変更）を反映する地図: 表示枠と、別ウィンドウの地図。"""
        return self.panes + [w.pane for w in self.gene_windows]

    def _build_detail_panel(self):
        self.detail_panel = QWidget()
        self.detail_panel.setMinimumWidth(260)
        layout = QVBoxLayout(self.detail_panel)
        layout.setContentsMargins(4, 0, 0, 0)
        self.detail = QTextBrowser()
        self.detail.setOpenLinks(False)
        self.detail.anchorClicked.connect(lambda url: self._open_link(url.toString()))
        WidthWatcher(self.detail).changed.connect(self._on_detail_resized)
        self.detail_controls = QVBoxLayout()
        # 説明欄の ◀ ▶: 表示した遺伝子・線・複合体の履歴をたどり、地図の選択もそれに合わせる
        self._detail_hist: list[tuple] = []   # (種類, キー, 表示枠)
        self._detail_pos = -1
        self._detail_nav = False
        nav = QHBoxLayout()
        self.detail_back = QPushButton("◀")
        self.detail_forward = QPushButton("▶")
        for button, step, tip in ((self.detail_back, -1, "前に表示した遺伝子・線に戻る"),
                                  (self.detail_forward, 1, "次に表示した遺伝子・線に進む")):
            button.setFixedWidth(34)
            button.setToolTip(tip)
            button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            button.clicked.connect(lambda _=False, s=step: self._detail_go(s))
            nav.addWidget(button)
        nav.addStretch(1)
        layout.addLayout(nav)
        self._update_detail_nav()
        layout.addWidget(self.detail, 1)
        layout.addLayout(self.detail_controls)
        # 一番下の Help（左のタブと同じ）: 出している説明（遺伝子・線・複合体・パラログ）の見方を、説明欄の新しいページとして出す
        detail_help = QPushButton("Help")
        detail_help.setToolTip("この説明欄の見方を表示します（◀ で戻れます）")
        detail_help.clicked.connect(self.show_detail_help)
        layout.addWidget(detail_help)
        self.clear_detail()

    # ================= 共有設定（表示枠から参照される） =================
    def layout_name(self) -> str:
        return self.layout_combo.currentData()

    def known_only(self) -> bool:
        # 「作用が分かっている関係のみ」の切り替えは廃止した（常にすべての関係をたどる）
        return False

    def color_mode(self) -> str:
        return self.color_combo.currentData()

    def edge_color_mode(self) -> str:
        return self.edge_color_combo.currentData()

    def orthogonal(self) -> bool:
        return True   # 線は常に遺伝子を避ける直角の折れ線で描く

    def label_options(self) -> tuple[bool, bool]:
        """凡例の「表示」欄: 種類記号（線ラベル）、+数（表示されていない下流の数）。"""
        o = self.display_options
        return o["symbols"], o["more"]

    def set_display_option(self, key: str, on: bool) -> None:
        """どれかの表示枠の凡例で「表示」欄のチェックを切り替えたとき。全表示枠に反映する。"""
        if key not in self.display_options:
            return
        self.display_options[key] = on
        for pane in self._views():
            pane.push_label_options()
        self._save_view()

    def _all_js(self, code: str) -> None:
        for pane in self._views():
            pane.js(code)

    # ================= 表示枠の管理 =================
    @staticmethod
    def _load_view() -> tuple[list[dict], str, str, dict, str, dict]:
        """前回の表示（表示枠・配置の方式・色分け・凡例で隠した項目）。"""
        default_layout = LAYOUT_CHOICES[0][1]
        try:
            data = json.loads(VIEW_FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return [{}], default_layout, "role", {}, "type", {}
        if "panes" in data:
            panes = [p for p in data["panes"] if isinstance(p, dict)][:MAX_PANES] or [{}]
            return (panes, data.get("layout", default_layout), data.get("color_mode", "role"),
                    data.get("hidden", {}), data.get("edge_color", "type"), data.get("display", {}))
        # 表示枠が 1 つだった頃の形式
        return [{"focus": data.get("focus", []), "up": data.get("up", DEFAULT_UP),
                 "down": data.get("down", DEFAULT_DOWN)}], default_layout, "role", {}, "type", {}

    @staticmethod
    def _load_setting(key: str, default: str, allowed) -> str:
        try:
            value = json.loads(VIEW_FILE.read_text(encoding="utf-8")).get(key)
        except (OSError, ValueError, AttributeError):
            value = None
        return value if value in allowed else default

    def _save_view(self) -> None:
        data = {"panes": [p.state() for p in self.panes], "layout": self.layout_combo.currentData(),
                "color_mode": self.color_combo.currentData(), "hidden": self.hidden_filters(),
                "conditions_off": sorted(self.conditions_off), "conditions_top": self.cond_top.isChecked(),
                "edge_color": self.edge_color_combo.currentData(), "display": self.display_options,
                "data_condition": self.data_cond_combo.currentData()}
        try:
            VIEW_FILE.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass

    def _create_pane(self, state: dict | None) -> GraphPane:
        pane = self._make_pane(state)
        pane.activated.connect(self.set_active)
        pane.nodeClicked.connect(lambda p, pid: self.show_node(pid, p))
        pane.edgeClicked.connect(lambda p, iid: self.show_edge(iid, p))
        pane.complexClicked.connect(lambda p, name: self.show_complex(name, p))
        pane.backgroundClicked.connect(lambda p: self.clear_detail())
        pane.viewChanged.connect(self._on_pane_view_changed)
        pane.closeRequested.connect(self.close_pane)
        pane.detachRequested.connect(self.detach_pane)
        pane.statusMessage.connect(self.statusMessage)
        pane.filterToggled.connect(lambda kind, key, shown, p=pane: self.toggle_filter(kind, key, shown, p))
        pane.filterReset.connect(lambda kind, p=pane: self.reset_filters(kind, p))
        pane.displayOptionChanged.connect(self.set_display_option)
        pane.pickedChanged.connect(self._on_picked_changed)
        pane.relationGene.connect(self._on_relation_gene)
        pane.helpRequested.connect(lambda _p: self.show_help("legend"))
        pane.backgroundClicked.connect(self._on_relation_background)
        self.panes.append(pane)
        if self.model:
            pane.set_completer(self._gene_names())
        return pane

    def add_pane(self, focus_pid: int | None = None) -> GraphPane | None:
        if len(self.panes) >= MAX_PANES:
            self.statusMessage.emit(f"表示枠は最大 {MAX_PANES} つまでです")
            return None
        pane = self._create_pane({"focus": [], "up": DEFAULT_UP, "down": DEFAULT_DOWN})
        self._arrange()
        self.set_active(pane)
        if self.model:
            pane.on_model_reloaded(use_default=False)
            if focus_pid is not None:
                pane.set_focus(focus_pid)
            else:
                pane.search.setFocus()
        self._save_view()
        return pane

    def close_pane(self, pane: GraphPane) -> None:
        if len(self.panes) <= 1:
            return
        self.panes.remove(pane)
        if self.detail_pane is pane:
            self.clear_detail()
        pane.setParent(None)
        pane.deleteLater()
        self._arrange()
        self.set_active(self.panes[0])
        self._rebuild_trf_panel()
        self._save_view()

    def set_active(self, pane: GraphPane) -> None:
        changed = self.active_pane is not pane
        self.active_pane = pane
        for p in self.panes:
            p.set_active(p is pane)
        if changed:
            self._rebuild_trf_panel()   # 左の TFs 一覧は操作中の表示枠の注目に合わせる
            self._update_condition_presence()
            # 経路は操作中の表示枠にだけ出す（ほかの枠は普段の地図に戻す）
            for p in self.panes:
                if p is not pane:
                    p.clear_relation()
            self._update_relation_genes()
            self._rel_timer.start()
            self.rel_window_button.setEnabled(False)

    def _arrange(self) -> None:
        """表示枠を並べ直す（最大 4 つ）。1 つ目・2 つ目は左右に、3 つ目は 1 つ目の下、4 つ目は 2 つ目の下（2×2 の格子）。

        列（縦の QSplitter）を使い回し、置き場所が変わる表示枠だけを動かす。QWebEngineView は親を付け替えると
        画面の更新が止まって拡大されたままぼやけることがあるので、枠を追加しただけのときは既存の枠を動かさない。
        大きさは、列の数が変わらなければ左右の幅をそのまま保ち、枠の数が変わった列だけ上下を等分する
        （枠を閉じても、ほかの枠の横幅は変えない）。
        """
        n = len(self.panes)
        columns = [self.panes[0::2], self.panes[1::2]]
        columns = [c for c in columns if c]
        old_widths = self.pane_area.sizes()
        old_counts = [col.count() for col in self.col_splitters]
        while len(self.col_splitters) < len(columns):
            col = QSplitter(Qt.Orientation.Vertical)
            col.setChildrenCollapsible(False)
            self.pane_area.addWidget(col)
            self.col_splitters.append(col)
        for col, group in zip(self.col_splitters, columns):
            for j, pane in enumerate(group):
                if col.indexOf(pane) != j:
                    col.insertWidget(j, pane)
        # 使わなくなった列（中の表示枠はすでに別の列へ移したか、閉じてある）を片付ける
        for old in self.col_splitters[len(columns):]:
            old.setParent(None)
            old.deleteLater()
        self.col_splitters = self.col_splitters[:len(columns)]
        for k, col in enumerate(self.col_splitters):
            if k >= len(old_counts) or old_counts[k] != col.count():
                col.setSizes([1000] * col.count())
        if len(old_widths) != len(self.col_splitters) or not all(old_widths):
            self.pane_area.setSizes([1000] * len(self.col_splitters))
        else:
            self.pane_area.setSizes(old_widths)
        for i, pane in enumerate(self.panes, start=1):
            pane.set_title(i, closable=n > 1)

    def _on_pane_view_changed(self, pane: GraphPane) -> None:
        self._save_view()
        self._rebuild_trf_panel()
        if pane is self.active_pane:
            self._update_relation_genes()   # 地図上の遺伝子が変わった
            self._update_condition_presence()

    def _gene_names(self) -> list[str]:
        return sorted(p.gene_name for p in self.model.proteins.values())

    # ================= データ =================
    def set_database(self, db: Database) -> None:
        self.db = db
        self._reload(use_default=True)

    def reload(self) -> None:
        """DB を読み直す。"""
        self._reload(use_default=False)

    def _reload(self, use_default: bool) -> None:
        self.model = PathwayModel(self.db.proteins(), self.db.interactions(), self.db.categories(),
                                  self.db.category_members())
        self._rebuild_condition_panel()
        names = self._gene_names()
        for window in list(self.gene_windows):
            window.close()
        for pane in self.panes:
            pane.set_completer(names)
            pane.on_model_reloaded(use_default)
        self._save_view()
        self.clear_detail()

    # ================= TFs の一覧 =================
    def _clear_layout(self, layout):
        """並びの中身を消す（入れ子の並びの中の部品も消す）。"""
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.setParent(None)
                widget.deleteLater()
            elif item.layout():
                self._clear_layout(item.layout())

    def _shown_nodes(self) -> set[int]:
        shown = set()
        for pane in self.panes:
            shown |= pane.sub.nodes
        return shown

    # 作用の色はアプリ全体で 促進＝赤・抑制＝青（地図の「線の色: 作用」と同じ。web/network.js の EFFECT_COLORS）
    TRF_EFFECT = {"activate": ("→", "促進", "#e53935"), "inhibit": ("⊣", "抑制", "#1e88e5"), "none": ("◇", "作用不明", "#757575")}

    def _rebuild_trf_panel(self):
        """操作中の表示枠で注目（オレンジ）・拡張（紫）している遺伝子ごとに、それを転写制御する転写因子を
        チェックボックスで並べる。遺伝子ごとに、題名 →「すべて表示」「すべて外す」→ 作用（促進・抑制・作用不明）ごとの
        開閉できる欄、の順。作用の欄は最初は閉じている（開いた欄は、作り直しても開いたまま）。
        同じ転写因子が複数の遺伝子の欄にあるときは、チェックが連動する。"""
        scroll = self.trf_scroll.verticalScrollBar().value()   # 作り直してもスクロール位置を保つ
        self._clear_layout(self.trf_layout)
        pane = self.active_pane
        if not self.model or pane is None:
            return
        targets = pane.trf_targets()
        if not targets:
            self.trf_layout.addWidget(QLabel("注目・拡張している遺伝子がありません"))
        boxes: dict[int, list[QCheckBox]] = {}   # 転写因子 → 各欄のチェックボックス（連動させる）

        def toggled(pid: int, on: bool):
            for other in boxes.get(pid, []):
                other.blockSignals(True)
                other.setChecked(on)
                other.blockSignals(False)
            pane.set_trf([pid], on)

        for g, kind in targets:
            regs = self.model.tx_adjacency.inc.get(g, set()) - {g}
            box = QFrame()
            box.setFrameShape(QFrame.Shape.StyledPanel)
            v = QVBoxLayout(box)
            v.setContentsMargins(6, 4, 6, 4)
            v.setSpacing(2)
            title = QLabel(self.model.names[g])   # 題名は遺伝子名だけ（注目＝橙・拡張＝紫の色で区別する）
            title.setStyleSheet("color: %s; font-weight: bold;" % ("#e65100" if kind == "focus" else "#6a1b9a"))
            v.addWidget(title)
            if not regs:
                note = QLabel("転写因子なし")
                note.setStyleSheet("color:#777;")
                v.addWidget(note)
                self.trf_layout.addWidget(box)
                continue
            order = sorted(regs, key=lambda n, g=g: self.model.tx_priority(n, g, regulator=True))
            buttons = QHBoxLayout()
            for text, on in (("すべて表示", True), ("すべて外す", False)):
                b = QPushButton(text)
                b.setFocusPolicy(Qt.FocusPolicy.NoFocus)   # Space・Enter で意図せず切り替わらないように
                b.clicked.connect(lambda _, ids=order, on=on: pane.set_trf(ids, on))
                buttons.addWidget(b)
            v.addLayout(buttons)
            for effect in ("activate", "inhibit", "none"):
                members = [n for n in order if self.model.tx_effect.get((n, g), "none") == effect]
                if not members:
                    continue
                mark, label, color = self.TRF_EFFECT[effect]
                shown = sum(n in pane.trf for n in members)
                section, inner = self._trf_section((g, effect), f"{mark} {label}（{len(members)}"
                                                   + (f"、表示 {shown}" if shown else "") + "）", color)
                for n in members:
                    elsewhere = n in pane.sub.nodes and n not in pane.trf   # 他の関係で既に表示中
                    shared = sum(n in self.model.tx_adjacency.inc.get(t, set()) for t, _ in targets) > 1
                    cb = QCheckBox(self.model.names[n] + (" 表示中" if elsewhere else "") + ("  ⇄" if shared else ""))
                    cb.setStyleSheet(f"QCheckBox {{ color: {color}; font-weight: normal; }}")
                    cb.setToolTip(self.model.proteins[n].description
                                  + ("\n⇄ 複数の遺伝子の TFs。チェックは連動します" if shared else ""))
                    cb.setChecked(n in pane.trf or elsewhere)
                    cb.setEnabled(not elsewhere)
                    cb.setFocusPolicy(Qt.FocusPolicy.NoFocus)
                    cb.toggled.connect(lambda on, pid=n: toggled(pid, on))
                    boxes.setdefault(n, []).append(cb)
                    inner.addWidget(cb)
                v.addWidget(section)
            self.trf_layout.addWidget(box)
        QTimer.singleShot(0, lambda: self.trf_scroll.verticalScrollBar().setValue(scroll))

    def _trf_section(self, key, title: str, color: str) -> tuple[QWidget, QVBoxLayout]:
        """TFs 一覧の、開閉できる欄（見出しのボタン＋中身）。key は開閉の状態を覚える鍵（遺伝子・作用）。
        返り値: (欄, 中身を入れる並び)。"""
        opened = getattr(self, "_trf_open", set())
        self._trf_open = opened
        box = QWidget()
        outer = QVBoxLayout(box)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        head = QToolButton()
        head.setText(title)
        head.setCheckable(True)
        head.setChecked(key in opened)
        head.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        head.setArrowType(Qt.ArrowType.DownArrow if key in opened else Qt.ArrowType.RightArrow)
        head.setAutoRaise(True)
        head.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        head.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        head.setStyleSheet("QToolButton { color: %s; font-weight: bold; text-align: left; border: none; }" % color)
        body = QWidget()
        body.setVisible(key in opened)
        v = QVBoxLayout(body)
        v.setContentsMargins(18, 0, 0, 2)
        v.setSpacing(1)

        def toggle(on: bool):
            body.setVisible(on)
            head.setArrowType(Qt.ArrowType.DownArrow if on else Qt.ArrowType.RightArrow)
            (opened.add if on else opened.discard)(key)

        head.toggled.connect(toggle)
        outer.addWidget(head)
        outer.addWidget(body)
        return box, v

    # ================= 詳細パネル =================
    def _set_controls(self, widgets):
        self._clear_layout(self.detail_controls)
        for w in widgets:
            self.detail_controls.addWidget(w)

    def clear_detail(self):
        """右側の説明欄を既定の表示に戻す（表示するものがないときは、マップの使い方）。"""
        self.selected = None
        self._set_controls([])
        self.detail.setHtml(help_text.MAP)

    def help_button(self, topic: str) -> QPushButton:
        """左のタブの一番下に置く「Help」ボタン（押すと右側の説明欄に使い方を出す）。"""
        button = QPushButton("Help")
        button.setToolTip("このタブの使い方を右側に表示します")
        button.clicked.connect(lambda: self.show_help(topic))
        return button

    def show_help(self, topic: str) -> None:
        """右側の説明欄に使い方を出す（tor_app/ui/help_text.py）。"""
        self.selected = None
        self._set_controls([])
        self.detail.setHtml(help_text.TOPICS[topic])

    def detail_help_topic(self, kind: str | None, key) -> str:
        """説明欄に出しているものの見方の種類（help_text.DETAIL_HELP のキー）。何も出していなければ map。"""
        if kind == "complex":
            return "paralog" if self.model and all(p in self.model.paralogs for p in str(key).split("・")) else "complex"
        return kind if kind in ("node", "edge") else "map"

    def show_detail_help(self) -> None:
        """説明欄の一番下の Help: 今の説明の見方を新しいページとして出す（履歴に入れ、◀ で前の説明に戻れる）。"""
        kind, key = self.selected or (None, None)
        if kind == "help":
            return
        topic = self.detail_help_topic(kind, key)
        self._push_detail("help", topic, self.detail_pane or self.active_pane)
        self._show_help_page(topic)

    def _show_help_page(self, topic: str) -> None:
        self.selected = ("help", topic)
        self._set_controls([])
        self.detail.setHtml(help_text.detail_help(topic))

    def _pane(self, pane: GraphPane | None) -> GraphPane:
        return pane if pane in self.panes else self.active_pane

    def render_html(self, kind: str, key, state: DetailState) -> str:
        """データベースの説明欄用: 地図の説明欄と同じ中身を、渡した状態で作る（表示枠の情報は出さない）。
        kind: node（遺伝子の番号）/ edge（関係の番号）/ complex（複合体・パラログの名前）。"""
        if self.model is None:
            return ""
        saved = self._st, self._render_pane
        self._st, self._render_pane = state, False
        try:
            if kind == "node" and key in self.model.proteins:
                return self._node_html(key)
            if kind == "edge" and key in self.model.interactions:
                return self._edge_html(key)
            if kind == "complex":
                return self._complex_html(key)
            return ""
        finally:
            self._st, self._render_pane = saved

    def toggle_detail(self, state: DetailState, target: str) -> bool:
        """説明欄の中の開閉（訳・一覧・条件の測定）。開閉のリンクなら状態を変えて True。"""
        kind, _, key = target.partition(":")
        if kind == "desc":
            if key == "translate":
                self._translate_failed.clear()   # 失敗していたら取り直す
            state.show_translation = key == "translate"
        elif kind == "list":
            (state.open_lists.discard if key in state.open_lists else state.open_lists.add)(key)
        elif kind == "cond":
            (state.open_conds.discard if key in state.open_conds else state.open_conds.add)(key)
        else:
            return False
        return True

    def _on_detail_resized(self) -> None:
        """説明欄の幅が変わった: 遺伝子の説明なら、条件名の折り返しを作り直す（スクロール位置は保つ）。"""
        if self.selected and self.selected[0] == "node" and self.model:
            bar = self.detail.verticalScrollBar()
            pos = bar.value()
            self._refresh_detail_text()
            bar.setValue(pos)

    def _refresh_detail_text(self):
        kind, key = self.selected
        if kind == "node" and key in self.model.proteins:
            self.detail.setHtml(self._node_html(key))
        elif kind == "edge" and key in self.model.interactions:
            self.detail.setHtml(self._edge_html(key))
        elif kind == "complex":
            self.detail.setHtml(self._complex_html(key))

    @staticmethod
    def _arrow(it) -> str:
        effect = resolve_effect(it.interaction_type, it.effect)
        directed = it.interaction_type != "binding" or effect != "none"
        return {"activate": "→", "inhibit": "⊣", "none": "─◇" if directed else "—"}[effect]

    def _link_edge(self, it) -> str:
        return (f"<a href='edge:{it.id}'>{html.escape(it.source.gene_name)} {self._arrow(it)} "
                f"{html.escape(it.target.gene_name)}</a> "
                f"<span style='color:#777'>{html.escape(type_label(it.interaction_type))}</span>")

    def _edge_items(self, edges, shown: set[int]) -> list[tuple[tuple, str]]:
        """上流・下流の一覧の行（並べ替えの鍵, HTML）。論文が複合体の名前で書いた関係（構成遺伝子ごとに広げてある。
        tor_app/complex_groups.py）は、遺伝子ごとに並べず「TORC1 → RPC82」の 1 行にまとめ、先頭に並べる（リンクは代表の関係）。"""
        items, grouped = [], {}
        for it in edges:
            marks = complex_groups.parse(it.evidence)
            if marks:
                label, side = marks[0]
                end = it.target_id if side == "上流" else it.source_id
                grouped.setdefault((label, side, end, it.interaction_type), []).append(it)
                continue
            items.append(((1, not (it.source_id in shown and it.target_id in shown),
                           it.source.gene_name, it.target.gene_name), self._link_edge(it)))
        for (label, side, end, kind), its in grouped.items():
            rep = min(its, key=lambda it: it.id)
            other = html.escape(self.model.names[end])
            text = f"{html.escape(label)} {self._arrow(rep)} {other}" if side == "上流" else \
                f"{other} {self._arrow(rep)} {html.escape(label)}"
            on_map = any(it.source_id in shown and it.target_id in shown for it in its)
            items.append(((0, not on_map, label if side == "上流" else self.model.names[end],
                           self.model.names[end] if side == "上流" else label),
                          f"<a href='edge:{rep.id}'>{text}</a> <span style='color:#777'>"
                          f"{html.escape(type_label(kind))}・複合体として"
                          f"{f'（{len(its)} 遺伝子）' if len(its) > 1 else ''}</span>"))
        return sorted(items, key=lambda x: x[0])

    def _node_html(self, pid: int) -> str:
        p = self.model.proteins[pid]
        ups = [it for it in self.model.interactions.values() if it.target_id == pid]
        downs = [it for it in self.model.interactions.values() if it.source_id == pid]
        known_only = self.known_only()
        level = self.model.levels(known_only).get(pid)
        place = (f"No. {self.model.layout_order(known_only)[pid]}"
                 f"・{'階層なし' if level is None else f'第{level + 1}階層'}")
        rows = [("Systematic 名", p.standard_name), ("配置の番号", place),
                ("ORF の確度（SGD）", p.protein_properties)]
        table = "".join(f"<tr><td style='color:#777;padding-right:8px'>{k}</td><td>{html.escape(v or '')}</td></tr>"
                        for k, v in rows)
        hidden = ""
        sub = self._pane(self.detail_pane).sub if self._render_pane else None
        if sub is not None:
            if pid in sub.nodes:
                hu, hd = sub.hidden_up.get(pid, 0), sub.hidden_down.get(pid, 0)
                if hu or hd:
                    hidden = f"<p style='color:#b26a00'>表示されていない上流 {hu} 個・下流 {hd} 個</p>"
            else:
                hidden = "<p style='color:#b26a00'>操作中の表示枠にはありません</p>"
            hidden += self._tf_pair_note(pid, ups + downs, sub)
        title = f"<h2 style='margin-bottom:2px'>{html.escape(p.gene_name)}</h2>"
        if self._render_pane:
            # 遺伝子名の右端に「注目」「拡張」（検索欄の吹き出しと同じ操作を、操作中の表示枠に）
            button = ("<a href='{0}:{1}' style='text-decoration:none;color:{2};font-weight:bold'>"
                      "<span style='background-color:{3}'>&nbsp;{4}&nbsp;</span></a>").format
            title = (f"<table width='100%' cellspacing='0' cellpadding='0'><tr><td>{title}</td>"
                     f"<td align='right' valign='middle' style='white-space:nowrap'>"
                     f"{button('mapfocus', pid, '#e65100', '#fff3e0', '注目')}&nbsp;"
                     f"{button('mapgrow', pid, '#6a1b9a', '#f3e5f5', '拡張')}</td></tr></table>")
        return (f"{title}"
                f"{hidden}"
                f"<table>{table}</table>{self._description_html(p.description or '')}{self._portal_html(p.gene_name)}"
                f"{self._data_html(p.standard_name or '')}"
                f"{self._edge_list(ups, sub.nodes if sub else set(), 'up', '上流')}"
                f"{self._edge_list(downs, sub.nodes if sub else set(), 'down', '下流')}")

    @staticmethod
    def _value_html(v: float | None, note: str = "") -> str:
        """log2 の比を、地図と同じ色（赤＝増える、青＝減る）の数字で出す。"""
        if v is None:
            return "<span style='color:#bbb'>–</span>"
        color = "#c62828" if v >= 0.58 else "#1565c0" if v <= -0.58 else "#555"
        weight = "bold" if abs(v) >= 1 else "normal"
        extra = f" <span style='color:#777;font-size:11px'>{html.escape(note)}</span>" if note else ""
        return f"<span style='color:{color};font-weight:{weight}'>{v:+.2f}</span>{extra}"

    def _data_html(self, orf: str) -> str:
        """条件ごとの変化（data/expression.db）: 条件ごとの mRNA・リン酸化・タンパク質量のまとめの表。
        条件の名前を押すと、その下に測定ごとの値と出典（論文へのリンク）が開く（もう一度押すと閉じる）。
        測定がない条件は、名前を灰色にして開けないようにする。色分けで選んでいる条件は太字。
        リン酸化が測られていても p < 0.05 の部位がない条件は、0 ではなく n.s. と出す（変わらなかったとは言えないため）。"""
        if not orf or not expression.available():
            return ""
        summary = expression.gene_summary(orf)
        if not summary:
            return ""
        labels = conditions.labels()
        cur = self.data_condition() if self.data_kind() else None
        kinds = [k for k in expression.KINDS if any(k in v for v in summary.values())]
        # 開いた文献の欄は表の外に出す（表の中に入れると、欄の長い行が列の幅を押し広げて条件名が折り返す）。
        # 表は開いた条件のところで区切るので、値の列の幅を固定して、区切った表どうしの列をそろえる
        # リン酸化の部位は値の下の 2 行目に書くので、値の列はどれも数字の幅で足りる
        widths = {"mrna": 64, "phospho": 72, "protein": 72}
        # 条件名の欄の幅（説明欄の幅から値の列と ▸・余白の分を引いたもの）。名前はこの幅で 2 行までに収める
        name_width = max(60, (self._st.width or self.detail.viewport().width()) - sum(widths[k] for k in kinds) - 28)
        col = "<td width='{}' style='text-align:right;white-space:nowrap'>{}</td>".format
        head = "".join(f"<td width='{widths[k]}' style='text-align:right;white-space:nowrap'><b>{expression.SHORT[k]}</b></td>"
                       for k in kinds)
        table = "<table width='100%' cellspacing='0' cellpadding='1'>{}</table>".format
        listed = expression.gene_points(orf)
        blocks, rows = [], [f"<tr><td></td>{head}</tr>"]
        for key in expression.condition_keys():
            if key not in summary:
                continue
            mine = [x for x in listed if key in x.conditions.split(";")]
            is_open = bool(mine) and key in self._st.open_conds
            name = self._two_lines(labels.get(key, key), name_width, bold=key == cur)
            if key == cur:
                name = f"<b>{name}</b>"
            if mine:
                link = f"<a href='cond:{html.escape(key)}' style='text-decoration:none'>{'▾' if is_open else '▸'} {name}</a>"
            else:   # 測定がない: 灰色で、開けない（▸ の分の幅は空けて名前の位置をそろえる）
                link = f"<span style='color:#999'><span style='color:transparent'>▸</span> {name}</span>"
            cells = "".join(col(widths[k], self._summary_cell(k, summary[key].get(k))) for k in kinds)
            rows.append(f"<tr><td style='white-space:nowrap'>{link}</td>{cells}</tr>")
            if is_open:
                blocks.append(table("".join(rows)))
                rows = []
                blocks.append(f"<table width='100%' cellspacing='0' cellpadding='0'><tr>"
                              f"<td style='padding:2px 6px 6px 14px;background-color:{self._literature_bg()}'>"
                              f"{self._measures_html(mine)}</td></tr></table>")
        if rows:
            blocks.append(table("".join(rows)))
        return "<h4 style='margin-bottom:2px'>条件ごとの log2 比</h4>" + "".join(blocks)

    def _two_lines(self, text: str, width: int, bold: bool = False) -> str:
        """条件名を width px の幅で 2 行までに折り返す（HTML、改行は <br>）。2 行に収まらない分は「…」で省く。
        Qt の表示は行数を限れないので、文字の幅を測って自分で折り返す。"""
        font = QFont(self.detail.font())
        font.setBold(bold)
        metrics = QFontMetrics(font)
        first = ""
        for ch in text:
            if metrics.horizontalAdvance(first + ch) > width:
                break
            first += ch
        rest = text[len(first):]
        if not rest:
            return html.escape(text)
        # 1 行目は、なるべく区切り（・や空白）の後ろで折る
        cut = max(first.rfind("・"), first.rfind(" "), first.rfind("（"))
        if cut > len(first) // 2:
            first, rest = first[:cut + 1], text[cut + 1:]
        second = metrics.elidedText(rest.strip(), Qt.TextElideMode.ElideRight, width)
        # 2 行目は ▸ の分だけ下げて、1 行目の名前の頭にそろえる
        return f"{html.escape(first.strip())}<br><span style='color:transparent'>▸</span> {html.escape(second)}"

    @staticmethod
    def _literature_bg() -> str:
        """条件の測定の一覧（開いた文献の欄）の背景色。明るい画面では淡い青、暗い画面では暗い青。"""
        dark = QApplication.palette().base().color().lightness() < 128
        return "#1f2b36" if dark else "#eaf1f8"

    def _summary_cell(self, kind: str, value: tuple[float, str] | None) -> str:
        """まとめの表の 1 つの値。リン酸化で、測られているが p < 0.05 の部位がない（値 0・部位なし）なら n.s.。"""
        if value is None:
            return self._value_html(None)
        if kind == "phospho" and value == (0.0, ""):
            return "<span style='color:#999'>n.s.</span>"
        v, note = value
        if kind == "phospho" and note:   # 部位は値の下の 2 行目に（同じ行に並べると欄が広がり、条件名が何行にも折り返す）
            return f"{self._value_html(v)}<br><span style='color:#777;font-size:11px'>{html.escape(note)}</span>"
        return self._value_html(v, note)

    @staticmethod
    def _clear(x) -> bool:
        """はっきりした変化か。mRNA・タンパク質量はいつも True、リン酸化は p < 0.05 か 2 倍以上の部位。"""
        return x.kind != "phospho" or (x.pval is not None and x.pval < 0.05) or abs(x.value) >= 1

    def _measures_html(self, points: list) -> str:
        """1 つの条件の測定ごとの値と出典。種類（mRNA・リン酸化・タンパク質量）ごとに小見出しを付け、
        1 つの測定を 2 行で出す: 1 行目に値・部位・出典、2 行目に説明と p 値（説明欄が狭くても崩れないように）。
        値の列は折り返さない。リン酸化は、はっきりした部位（_clear）を先に並べ、それ以外の部位は後に灰色の小さい字で並べる。"""
        parts = []
        for kind, title in expression.KINDS.items():
            rows = []
            for x in sorted((x for x in points if x.kind == kind), key=lambda x: (not self._clear(x), -abs(x.value))):
                ref = (f"<a href='https://pubmed.ncbi.nlm.nih.gov/{x.pmid}/'>{html.escape(x.source)}</a>"
                       if x.pmid else html.escape(x.source))
                if not self._clear(x):
                    rows.append(f"<tr><td align='right' style='white-space:nowrap;padding:2px 8px 0 0;color:#999;font-size:11px'>"
                                f"{x.value:+.2f}</td><td style='color:#999;font-size:11px;padding-top:2px'>"
                                f"{html.escape(x.site)}・{html.escape(x.label)}・p = {x.pval:.2g} {ref}</td></tr>")
                    continue
                site = f"<b>{html.escape(x.site)}</b> " if x.site else ""
                sig = (f" <span style='color:#777;font-size:11px'>p = {x.pval:.2g}・補正後 {x.padj:.2g}</span>"
                       if x.padj is not None else "")
                rows.append(f"<tr><td align='right' style='white-space:nowrap;padding:3px 8px 0 0'>{self._value_html(x.value)}</td>"
                            f"<td style='padding-top:3px'>{site}{ref}</td></tr>"
                            f"<tr><td></td><td style='color:#999'>{html.escape(x.label)}{sig}</td></tr>")
            if rows:
                more = f"<div style='color:#777'>ほか {len(rows) - 30} 件</div>" if len(rows) > 30 else ""
                parts.append(f"<div style='margin-top:4px'><b>{title}</b></div>"
                             f"<table cellspacing='0' cellpadding='0'>{''.join(rows[:30])}</table>{more}")
        return "".join(parts)

    def portal_complexes(self) -> list[tuple[str, str, set[str], str]]:
        """data/complex_portal.tsv の複合体: (番号, 名前, 構成する遺伝子名（大文字）, 説明)。"""
        if getattr(self, "_portal_list", None) is None:
            self._portal_list = []
            try:
                with open(resource_path("data", "complex_portal.tsv"), encoding="utf-8") as f:
                    next(f)
                    for line in f:
                        ac, name, genes, *rest = line.rstrip("\n").split("\t")
                        self._portal_list.append((ac, name, {g.upper() for g in genes.split(";")}, rest[0] if rest else ""))
            except (OSError, ValueError, StopIteration):
                pass
        return self._portal_list

    def portal_by_gene(self) -> dict[str, list[tuple[str, str]]]:
        if getattr(self, "_portal", None) is None:
            self._portal = {}
            for ac, name, genes, _desc in self.portal_complexes():
                for g in genes:
                    self._portal.setdefault(g, []).append((ac, name))
        return self._portal

    def portal_category(self, ac: str) -> str | None:
        """Complex Portal の番号（CPX-…）→ その複合体のカテゴリの名前。"""
        if not self.model:
            return None
        return next((c.name for c in self.model.categories.values() if c.ref == ac and c.is_complex), None)

    def _portal_html(self, gene: str) -> str:
        """Complex Portal で、この遺伝子が構成要素になっている複合体（data/complex_portal.tsv）。名前を押すと
        アプリの中の複合体の説明を出す（出典の Complex Portal へのリンクは、複合体の説明の側に出す）。"""
        items = self.portal_by_gene().get(gene.upper(), [])
        out = ""
        if items:
            links = "".join(f"<li><a href='cpx:{html.escape(ac)}'>{html.escape(name)}</a></li>" for ac, name in items)
            out = f"<h4 style='margin-bottom:2px'>所属する複合体（Complex Portal）</h4><ul style='margin-top:0'>{links}</ul>"
        # パラログ（役割が重なりうる相手）。組の名前を押すと根拠を出す
        pid = self.model.by_name.get(gene.upper()) if self.model else None
        pairs = [n for n, genes in self.model.paralogs.items() if pid in genes] if pid is not None else []
        if pairs:
            gene_link = lambda g: f"<a href='node:{g}'>{html.escape(self.model.names[g])}</a>"   # noqa: E731
            mates = "".join(f"<li>{'・'.join(gene_link(g) for g in self.model.paralogs[n] if g != pid)} "
                            f"<a href='paralog:{html.escape(n)}' style='color:#777'>根拠</a></li>" for n in pairs)
            out += f"<h4 style='margin-bottom:2px'>パラログ</h4><ul style='margin-top:0'>{mates}</ul>"
        return out

    def _tf_pair_note(self, pid: int, relations: list, sub) -> str:
        """転写因子どうしの線を地図で省略していることの説明（相手も地図にあるのに描いていない線）。"""
        model = self.model
        omitted = [it for it in relations if it.source_id in sub.nodes and it.target_id in sub.nodes
                   and model.tf_pair_hidden(it, sub)]
        if not omitted:
            return ""
        names = sorted({model.names[it.source_id if it.source_id != pid else it.target_id] for it in omitted})
        shown = "、".join(names[:6]) + (f" ほか {len(names) - 6} 個" if len(names) > 6 else "")
        return f"<p style='color:#b26a00'>省いた転写因子どうしの線 {len(omitted)} 本: {html.escape(shown)}</p>"

    def _description_html(self, text: str) -> str:
        """説明欄: 英語の原文。「日本語訳を表示」を押したときだけ、その下に訳を出す（押すまで通信しない）。"""
        if not text:
            return ""
        link = "<a href='desc:{}' style='font-size:11px'>{}</a>".format
        note = "<span style='color:{};font-size:11px'>{}</span>".format
        original = f"<p>{html.escape(text)}</p>"
        if not self._st.show_translation:
            return original + link("translate", "日本語訳を表示")
        translated = self.translator.cached(text)
        if translated is not None:
            return (original + "<p style='color:#37474f;background:#f5f7f8;padding:4px'>"
                    f"{html.escape(translated)}</p>" + link("hide", "訳を隠す") + " " + note("#999", "機械翻訳"))
        if text in self._translate_failed:
            return (original + note("#b26a00", f"翻訳できませんでした: {self._translate_failed[text]} ")
                    + link("translate", "再試行"))
        self._request_translation(text)
        return original + note("#999", "翻訳中…")

    def _request_translation(self, text: str) -> None:
        if text in self._translating:
            return
        self._translating.add(text)

        def work():
            result, reason = None, ""
            try:
                result = self.translator.translate(text)
            except Exception as e:  # noqa: BLE001 - 理由は translate.failure_reason が文にする
                reason = failure_reason(e)
            self._translation_signal.done.emit(text, result, reason)

        threading.Thread(target=work, daemon=True).start()

    def _on_translated(self, text: str, result, reason: str) -> None:
        self._translating.discard(text)
        if result is None:
            self._translate_failed[text] = reason
        # 表示中の遺伝子の説明なら、訳（または失敗の表示）に差し替える
        if self.selected and self.selected[0] == "node" and self._selected_description() == text:
            self._refresh_detail_text()
        self.translationDone.emit()

    def _selected_description(self) -> str:
        if self.selected and self.selected[0] == "node" and self.selected[1] in self.model.proteins:
            return self.model.proteins[self.selected[1]].description or ""
        if self.selected and self.selected[0] == "complex" and self.selected[1] in self.model.categories:
            return self.model.categories[self.selected[1]].description or ""
        return ""

    def _edge_list(self, edges, shown: set[int], key: str = "", title: str = "") -> str:
        """上流・下流の関係の一覧（title があれば「上流 (件数)」の見出しも付ける）。表示中の相手を先に並べる。
        MAX_LIST 件を超える分は畳み、「ほか N 件を表示」で開ける（key: up / down など）。"""
        items = self._edge_items(edges, shown)
        head = f"<h4>{title} ({len(items)})</h4>" if title else ""
        if not items:
            return head + "<span style='color:#999'>なし</span>"
        opened = key in self._st.open_lists
        lines = [h for _, h in (items if opened else items[:MAX_LIST])]
        if len(items) > MAX_LIST:
            lines.append(f"<a href='list:{key}' style='color:#555'>▴ 閉じる</a>" if opened else
                         f"<a href='list:{key}' style='color:#555'>▸ ほか {len(items) - MAX_LIST} 件を表示</a>")
        return head + "<br>".join(lines)

    def _edge_html(self, iid: int) -> str:
        it = self.model.interactions[iid]
        effect = resolve_effect(it.interaction_type, it.effect)
        level = self.model.confidence.get(iid, "U")
        rows = [("種類", html.escape(type_label(it.interaction_type))),
                ("作用の向き", html.escape(EFFECTS[effect])
                 + (" <span style='color:#e65100'>⚠ 出典で食い違いあり</span>" if "⚠" in (it.evidence or "") else "")),
                ("向きの根拠", html.escape(self._effect_basis(it, effect))),
                ("確度", html.escape(confidence.label(level))),
                ("条件", html.escape("・".join(conditions.labels().get(k, k) for k in conditions.split(it.conditions))
                                     or conditions.NONE_LABEL))]
        # 文献から拾った性質（組む相手・部位など）は、値のあるものだけ
        rows += [(label, html.escape(detail_text(getattr(it, name, "") or ""))) for name, label in DETAILS
                 if getattr(it, name, "")]
        table = "".join(f"<tr><td style='color:#777;padding-right:8px;vertical-align:top'>{k}</td>"
                        f"<td>{v}</td></tr>" for k, v in rows)
        a, b = it.source.gene_name, it.target.gene_name
        sgd = (f"<p style='font-size:11px;color:#777'>参照データで確かめる: "
               f"<a href='https://www.yeastgenome.org/locus/{a}/interaction'>SGD {html.escape(a)} の相互作用</a>・"
               f"<a href='https://www.yeastgenome.org/locus/{a}/regulation'>{html.escape(a)} の制御</a>・"
               f"<a href='https://www.yeastgenome.org/locus/{b}/interaction'>SGD {html.escape(b)} の相互作用</a>・"
               f"<a href='https://www.yeastgenome.org/locus/{b}/regulation'>{html.escape(b)} の制御</a></p>")
        return (f"<h2 style='margin-bottom:2px'><a href='node:{it.source_id}'>{html.escape(a)}</a>"
                f" → <a href='node:{it.target_id}'>{html.escape(b)}</a></h2>"
                f"<table>{table}</table>"
                f"<h4 style='margin-bottom:2px'>根拠・文献</h4>{self._evidence_html(it.evidence or '')}{sgd}")

    @staticmethod
    def _effect_basis(it, effect: str) -> str:
        """作用の向きを何から決めたか（根拠欄から読み取る）。分からなければ空。"""
        ev = it.evidence or ""
        if not it.effect:
            return f"記録がなく、{type_label(it.interaction_type)}の既定値"
        if effect == "none":
            return confidence.UNKNOWN_REASONS[confidence.unknown_reason(ev)]
        return ("文献で確認" if ev.startswith("文献で確認") else
                "転写因子の誘導実験 IDEA" if "作用の向き: IDEA" in ev else
                "SGD の GO 注釈" if "作用の向き: SGD GO" in ev or ev.startswith("SGD GO") else
                "GO-CAM" if "作用の向き: GO-CAM" in ev or ev.startswith("GO-CAM") else
                "破壊株データからの推定" if "作用の向き: 破壊株データ" in ev else
                "条件ごとの発現からの推定（間接の作用を含む）" if "作用の向き: 条件ごとの発現" in ev else
                "YEASTRACT+ の発現の報告" if "TF acting as" in ev else
                "構造確認用のサンプル" if "サンプル" in ev else "")

    @staticmethod
    def _evidence_html(evidence: str) -> str:
        """根拠欄を出典ごとの行に分け、PubMed の番号を外部へのリンクにする。"""
        if not evidence.strip():
            return "<span style='color:#999'>根拠の記録はありません</span>"

        def link(text: str) -> str:
            text = html.escape(text)
            # PMID: 123, 456 ほか → PubMed へのリンク
            text = re.sub(r"(PMID:? )([\d, ]+)", lambda m: m.group(1) + ", ".join(
                f"<a href='https://pubmed.ncbi.nlm.nih.gov/{n.strip()}/'>{n.strip()}</a>"
                for n in m.group(2).split(",") if n.strip()), text)
            return text

        lines = []
        for part in (p.strip() for p in evidence.split("; ")):
            if not part:
                continue
            label, color = next((v for k, v in EVIDENCE_SOURCES if part.startswith(k)), ("", "#455a64"))
            badge = (f"<span style='color:{color};font-weight:bold'>[{label}]</span> " if label else "")
            style = " style='color:#e65100'" if part.startswith("⚠") else ""
            lines.append(f"<div{style}>{badge}{link(part)}</div>")
        return "".join(lines)

    def paralog_html(self, name: str, heading: bool = True) -> str:
        """パラログの組の説明: 組の遺伝子、候補の出典、働きが重なる根拠（遺伝的相互作用・PMID・GO の重なり）。"""
        cat = self.model.categories.get(name) if self.model else None
        genes = self.model.paralogs.get(name, []) if self.model else []
        links = "・".join(f"<a href='node:{g}'>{html.escape(self.model.names[g])}</a>" for g in genes)
        lines = []
        for line in (cat.description if cat else "").split("\n"):
            text = html.escape(line)
            text = re.sub(r"(\d{6,9})", lambda m: f"<a href='https://pubmed.ncbi.nlm.nih.gov/{m.group(1)}/'>{m.group(1)}</a>", text) \
                if line.startswith("両方を壊すと") else text
            lines.append(f"<li>{text}</li>")
        title = f"<h2 style='margin-bottom:2px'>{html.escape(name)} パラログ</h2>" if heading else \
            f"<h4 style='margin-bottom:2px'>{html.escape(name)}</h4>"
        return f"{title}<p>{links}</p><ul style='margin-top:0'>{''.join(lines)}</ul>"

    def _complex_html(self, name: str) -> str:
        """地図の複合体の枠の説明: 構成する遺伝子と、Complex Portal の説明（出典へのリンク付き）。
        パラログの枠（名前は組を「・」でつないだもの）なら、組ごとの説明。"""
        pairs = name.split("・")
        if all(p in self.model.paralogs for p in pairs):
            if len(pairs) == 1:
                return self.paralog_html(pairs[0])
            return ("<h2 style='margin-bottom:2px'>パラログ</h2>"
                    + "".join(self.paralog_html(p, heading=False) for p in pairs))
        members = self.model.all_complexes().get(name, [])
        items = "".join(f"<li><a href='node:{m}'>{html.escape(self.model.proteins[m].gene_name)}</a></li>"
                        for m in sorted(members, key=lambda m: self.model.names[m]))
        cat = self.model.categories.get(name)
        about = ""
        if cat and cat.ref:
            about += (f"<p>出典: <a href='https://www.ebi.ac.uk/complexportal/complex/{html.escape(cat.ref)}'>"
                      f"Complex Portal {html.escape(cat.ref)}</a></p>")
        if cat and cat.description:
            about += f"<h4 style='margin-bottom:2px'>説明</h4>{self._description_html(cat.description)}"
        return (f"<h2>{html.escape(name)} 複合体</h2>{about}<h4>構成する遺伝子 ({len(members)})</h4><ul>{items}</ul>"
                + self._complex_edges(name, members))

    def _complex_edges(self, name: str, members: list[int]) -> str:
        """複合体の上流・下流: 構成遺伝子の関係（複合体の中どうしは除く）。論文が複合体の名前で書いた関係
        （data/complex_groups.csv。この複合体の Complex Portal の番号に当たるもの）は 1 行にまとめ、先頭に並べる。"""
        inside = set(members)
        cat = self.model.categories.get(name)
        labels = set(complex_groups.labels_for_portal(cat.ref if cat else ""))
        ups, downs = [], []
        for it in self.model.interactions.values():
            marks = complex_groups.parse(it.evidence)
            mine = {label for label, _ in marks} & labels
            if it.source_id in inside and it.target_id in inside:
                continue
            if it.target_id in inside or any(side == "下流" and label in mine for label, side in marks):
                ups.append(it)
            elif it.source_id in inside or any(side == "上流" and label in mine for label, side in marks):
                downs.append(it)
        sub = self._pane(self.detail_pane).sub if self._render_pane else None
        shown = sub.nodes if sub else set()
        return (self._edge_list(ups, shown, "cup", "上流") + self._edge_list(downs, shown, "cdown", "下流"))

    def _open_link(self, target: str):
        if target.startswith(("http://", "https://")):
            QDesktopServices.openUrl(QUrl(target))   # PubMed・SGD などはブラウザで開く
            return
        kind, _, key = target.partition(":")
        if self.toggle_detail(self.detail_state, target):
            # 開閉は説明欄のスクロール位置を保つ
            bar = self.detail.verticalScrollBar()
            pos = bar.value()
            self._refresh_detail_text()
            bar.setValue(pos)
        elif kind == "node":
            self.show_node(int(key), self.detail_pane)
        elif kind in ("mapfocus", "mapgrow") and self.model and int(key) in self.model.proteins:
            # 説明欄の「注目」「拡張」: 操作中の表示枠で、検索欄の吹き出しと同じ操作をする
            pane = self.active_pane
            (pane.change_focus if kind == "mapfocus" else pane.expand_gene)(int(key))
        elif kind == "paralog":
            self.show_complex(key, self.detail_pane)
        elif kind == "cpx":
            name = self.portal_category(key)
            if name:
                self.show_complex(name, self.detail_pane)
            else:   # DB にカテゴリがないときは、出典を開く
                QDesktopServices.openUrl(QUrl(f"https://www.ebi.ac.uk/complexportal/complex/{key}"))
        elif kind == "edge":
            self.show_edge(int(key), self.detail_pane)

    # ---- 説明欄の履歴（◀ ▶） ----
    DETAIL_HISTORY_MAX = 50

    def _push_detail(self, kind: str, key, pane) -> None:
        if self._detail_nav:
            return
        if 0 <= self._detail_pos < len(self._detail_hist) and self._detail_hist[self._detail_pos][:2] == (kind, key):
            return
        del self._detail_hist[self._detail_pos + 1:]
        self._detail_hist.append((kind, key, pane))
        del self._detail_hist[:-self.DETAIL_HISTORY_MAX]
        self._detail_pos = len(self._detail_hist) - 1
        self._update_detail_nav()

    def _update_detail_nav(self) -> None:
        self.detail_back.setEnabled(self._detail_pos > 0)
        self.detail_forward.setEnabled(self._detail_pos < len(self._detail_hist) - 1)

    def _detail_go(self, step: int) -> None:
        """説明欄の ◀ ▶: 履歴の遺伝子・線・複合体を出し直し、地図でもそれを選ぶ（遺伝子は緑の選択、線は強調）。"""
        pos = self._detail_pos + step
        if not 0 <= pos < len(self._detail_hist) or not self.model:
            return
        self._detail_pos = pos
        kind, key, pane = self._detail_hist[pos]
        if pane not in self._views():
            pane = self.active_pane
        self._detail_nav = True
        try:
            if kind == "node" and key in self.model.proteins:
                picked = [f"p{key}"] if key in pane.sub.nodes else []
                pane.js(f"app.setPicked({json.dumps(picked)})")
                self.show_node(key, pane)
            elif kind == "edge" and key in self.model.interactions:
                pane.js("app.setPicked([])")
                self.show_edge(key, pane)
            elif kind == "complex":
                pane.js("app.setPicked([])")
                self.show_complex(key, pane)
            elif kind == "help":
                self._show_help_page(key)
        finally:
            self._detail_nav = False
        self._update_detail_nav()

    def show_node(self, pid: int, pane: GraphPane | None = None):
        if pid not in self.model.proteins:
            return
        self._push_detail("node", pid, self._pane(pane))
        self.detail_pane = self._pane(pane)
        if self.selected != ("node", pid):
            self.detail_state.reset()   # 別の遺伝子を開いたら、訳と一覧を閉じる
        self.selected = ("node", pid)
        self.detail.setHtml(self._node_html(pid))
        self._set_controls([])
    def show_complex(self, name: str, pane: GraphPane | None = None):
        self._push_detail("complex", name, self._pane(pane))
        self.detail_pane = self._pane(pane)
        self.selected = ("complex", name)
        self.detail.setHtml(self._complex_html(name))
        self._set_controls([])

    def show_edge(self, iid: int, pane: GraphPane | None = None):
        if iid not in self.model.interactions:
            return
        self._push_detail("edge", iid, self._pane(pane))
        self.detail_pane = self._pane(pane)
        self.selected = ("edge", iid)
        self.detail.setHtml(self._edge_html(iid))
        # 地図でその線に注目する（転写因子どうしなど、ふだん省く線でも見せる）
        target = pane if pane is not None else self.detail_pane
        target.js(f"app.focusEdge({json.dumps('e' + str(iid))})")
        self._set_controls([])
