"""遺伝子の説明（英語）の日本語訳。

Google 翻訳の非公式の窓口（キー不要）を使う。予告なく使えなくなったり、回数を制限されたりすることがあるため、
訳した結果はこの PC に保存して再利用し、訳せなかったときは原文のまま表示する。
サーバー（tor_app/server.py）があれば、新しく訳したものを送り、みんなの訳を取り込む（通信の回数を減らす）。
"""
import json
import threading
import urllib.error
import urllib.parse
import urllib.request

from . import server
from .paths import user_data_dir

CACHE_FILE = user_data_dir() / "translations_ja.json"
URL = "https://translate.googleapis.com/translate_a/single"
TIMEOUT = 10   # 秒


class Translator:
    def __init__(self):
        self._lock = threading.Lock()
        try:
            self._cache: dict[str, str] = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self._cache = {}

    def cached(self, text: str) -> str | None:
        with self._lock:
            return self._cache.get(text)

    def translate(self, text: str) -> str:
        """text を日本語に訳す（通信するので時間がかかる。画面の処理とは別のスレッドから呼ぶ）。失敗したら例外。"""
        hit = self.cached(text)
        if hit is not None:
            return hit
        query = urllib.parse.urlencode({"client": "gtx", "sl": "en", "tl": "ja", "dt": "t", "q": text})
        request = urllib.request.Request(f"{URL}?{query}", headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
            data = json.loads(response.read().decode("utf-8"))
        # data[0] は文ごとの [訳, 原文, ...] の並び
        result = "".join(seg[0] for seg in data[0] if seg and seg[0])
        if not result:
            raise ValueError("訳が空でした")
        with self._lock:
            self._cache[text] = result
            self._save()
        server.note_new_translation(text, result)
        return result

    def merge(self, shared: dict[str, str]) -> int:
        """サーバーから取ってきた訳のうち、手元にない原文の訳を加える（手元の訳は変えない）。加えた数を返す。"""
        with self._lock:
            new = {k: v for k, v in shared.items() if k not in self._cache}
            if new:
                self._cache.update(new)
                self._save()
        return len(new)

    def _save(self) -> None:
        try:
            CACHE_FILE.write_text(json.dumps(self._cache, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass


def failure_reason(error: Exception) -> str:
    """translate() が失敗したときに画面に出す理由。"""
    if isinstance(error, urllib.error.HTTPError):
        return ("翻訳サービスの利用回数の制限に達しました。しばらく時間をおいてから再試行してください"
                if error.code == 429 else f"翻訳サービスがエラーを返しました: {error.code}")
    if isinstance(error, (urllib.error.URLError, TimeoutError, OSError)):
        return "翻訳サービスに接続できませんでした。インターネットへの接続を確認してください"
    return "翻訳サービスの応答を読み取れませんでした"   # 応答の形式が変わったときなど
