"""条件ごとの発現・リン酸化・タンパク質量（data/expression.db。tools/build_expression.py が作る）を読む。

地図の DB とは別の読み取り専用のファイル。遺伝子は systematic 名（ORF）で引く。値はどれも対照（処理前・未処理）との
log2 の比。種類（kind）:
- mrna: mRNA の量（SGD の発現データ。条件ごとに測定の値の中央値）
- phospho: リン酸化（Leutert et al. 2023。条件ごとに、変化の最も大きい部位の値）
- protein: タンパク質の量（Leutert et al. 2023 の 30 条件）
"""
import sqlite3
from dataclasses import dataclass

from . import conditions
from .paths import resource_path

KINDS = {"mrna": "発現（mRNA）", "phospho": "リン酸化", "protein": "タンパク質量"}
SHORT = {"mrna": "mRNA", "phospho": "リン酸化", "protein": "タンパク質"}   # 説明欄の表の見出し（折り返さない短い名前）

_con: sqlite3.Connection | None = None
_missing = False


def _db() -> sqlite3.Connection | None:
    global _con, _missing
    if _con is None and not _missing:
        path = resource_path("data", "expression.db")
        if not path.exists():
            _missing = True
            return None
        _con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, check_same_thread=False)
    return _con


def available() -> bool:
    return _db() is not None


def condition_keys() -> list[str]:
    """データのある条件のキー（data/conditions.csv の並び）。"""
    con = _db()
    if con is None:
        return []
    have = {c for (c,) in con.execute("SELECT DISTINCT condition FROM summary")}
    return [c.key for c in conditions.load() if c.key in have]


def kinds_for(condition: str) -> list[str]:
    con = _db()
    if con is None:
        return []
    have = {k for (k,) in con.execute("SELECT DISTINCT kind FROM summary WHERE condition = ?", (condition,))}
    return [k for k in KINDS if k in have]


def values(kind: str, condition: str) -> dict[str, tuple[float, str]]:
    """ORF → (値, 補足)。補足はリン酸化の部位（補正後も有意なら末尾に "*"）。"""
    con = _db()
    if con is None:
        return {}
    return {orf: (v, d) for orf, v, d in con.execute(
        "SELECT g.orf, s.value, s.detail FROM summary s JOIN genes g ON g.id = s.gene_id "
        "WHERE s.kind = ? AND s.condition = ?", (kind, condition))}


def measures(kind: str, condition: str) -> list[dict]:
    """その条件の測定の一覧（説明欄・Help 用）。"""
    con = _db()
    if con is None:
        return []
    return [dict(id=i, label=l, source=s, pmid=p, detail=d, flag=f or "")
            for i, l, s, p, d, f in con.execute(
                "SELECT id, label, source, pmid, detail, flag FROM measures WHERE kind = ? "
                "AND (';' || conditions || ';') LIKE ? ORDER BY id", (kind, f"%;{condition};%"))]


@dataclass
class Point:
    kind: str
    conditions: str
    label: str
    source: str
    pmid: str
    value: float
    site: str = ""
    pval: float | None = None
    padj: float | None = None


def gene_points(orf: str) -> list[Point]:
    """1 つの遺伝子の、すべての測定の値（mRNA・リン酸化の部位・タンパク質量）。"""
    con = _db()
    if con is None:
        return []
    row = con.execute("SELECT id FROM genes WHERE orf = ?", (orf.upper(),)).fetchone()
    if row is None:
        return []
    gid = row[0]
    out = [Point("mrna", c, l, s, p, v) for c, l, s, p, v in con.execute(
        "SELECT m.conditions, m.label, m.source, m.pmid, x.value FROM mrna x JOIN measures m ON m.id = x.measure_id "
        "WHERE x.gene_id = ? ORDER BY m.id", (gid,))]
    out += [Point("phospho", c, l, s, p, v, site, pv, pa) for c, l, s, p, site, v, pv, pa in con.execute(
        "SELECT m.conditions, m.label, m.source, m.pmid, x.site, x.value, x.pval, x.padj FROM phospho x "
        "JOIN measures m ON m.id = x.measure_id WHERE x.gene_id = ? ORDER BY m.id, x.site", (gid,))]
    out += [Point("protein", c, l, s, p, v, "", pv, pa) for c, l, s, p, v, pv, pa in con.execute(
        "SELECT m.conditions, m.label, m.source, m.pmid, x.value, x.pval, x.padj FROM protein x "
        "JOIN measures m ON m.id = x.measure_id WHERE x.gene_id = ? ORDER BY m.id", (gid,))]
    return out


def gene_summary(orf: str) -> dict[str, dict[str, tuple[float, str]]]:
    """1 つの遺伝子の、条件ごとのまとめ: 条件 → {種類: (値, 補足)}。"""
    con = _db()
    if con is None:
        return {}
    out: dict[str, dict[str, tuple[float, str]]] = {}
    for cond, kind, v, d in con.execute(
            "SELECT s.condition, s.kind, s.value, s.detail FROM summary s JOIN genes g ON g.id = s.gene_id "
            "WHERE g.orf = ?", (orf.upper(),)):
        out.setdefault(cond, {})[kind] = (v, d)
    return out


def measure_counts() -> dict[str, int]:
    """論文（PMID）→ その論文から取った測定の数（情報源タブの根拠の数に足す）。"""
    con = _db()
    if con is None:
        return {}
    return {p: n for p, n in con.execute("SELECT pmid, COUNT(*) FROM measures WHERE pmid != '' GROUP BY pmid")}
